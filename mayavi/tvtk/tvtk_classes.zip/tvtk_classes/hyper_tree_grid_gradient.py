# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.hyper_tree_grid_algorithm import HyperTreeGridAlgorithm


class HyperTreeGridGradient(HyperTreeGridAlgorithm):
    r"""
    HyperTreeGridGradient - Compute the gradient of a scalar field on
    a Hyper Tree Grid.
    
    Superclass: HyperTreeGridAlgorithm
    
    This filter compute the gradient of a given cell scalars array on a
    Hyper Tree Grid. This result in a new array attached to the original
    input.
    
    @sa
    HyperTreeGrid HyperTreeGridAlgorithm GradientFilter
    
    @par Thanks: This class was created by Charles Gueunet, 2022 This
    work was supported by Commissariat a l'Energie Atomique CEA, DAM,
    DIF, F-91297 Arpajon, France.
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkHyperTreeGridGradient, obj, update, **traits)
    
    compute_divergence = tvtk_base.false_bool_trait(desc=\
        r"""
        Enable / disable divergence computation. default is Off.
        """
    )

    def _compute_divergence_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetComputeDivergence,
                        self.compute_divergence_)

    compute_gradient = tvtk_base.true_bool_trait(desc=\
        r"""
        Enable / disable gradient computation. default is On.
        """
    )

    def _compute_gradient_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetComputeGradient,
                        self.compute_gradient_)

    compute_q_criterion = tvtk_base.false_bool_trait(desc=\
        r"""
        Enable / disable q-criterion computation. default is Off.
        """
    )

    def _compute_q_criterion_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetComputeQCriterion,
                        self.compute_q_criterion_)

    compute_vorticity = tvtk_base.false_bool_trait(desc=\
        r"""
        Enable / disable vorticity computation. default is Off.
        """
    )

    def _compute_vorticity_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetComputeVorticity,
                        self.compute_vorticity_)

    extensive_computation = tvtk_base.false_bool_trait(desc=\
        r"""
        Do we apply ratio in unlimited mode for the gradient computation
        ? No effect in Unstructured mode Default is false (intensive
        computation)
        """
    )

    def _extensive_computation_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetExtensiveComputation,
                        self.extensive_computation_)

    divergence_array_name = traits.String('Divergence', enter_set=True, auto_set=False, desc=\
        r"""
        Set/Get the name of divergence vector array.
        """
    )

    def _divergence_array_name_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetDivergenceArrayName,
                        self.divergence_array_name)

    gradient_array_name = traits.String('Gradient', enter_set=True, auto_set=False, desc=\
        r"""
        Set/Get the name of gradient vector array.
        """
    )

    def _gradient_array_name_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetGradientArrayName,
                        self.gradient_array_name)

    mode = traits.Trait(0, traits.Range(0, 1, enter_set=True, auto_set=False), desc=\
        r"""
        Set/Get the gradient computation method to use:
        * Unlimited: virtually reffine neighbors
        * Unstructured: compute gradient like in UG Dfault is UNLIMITED
        """
    )

    def _mode_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetMode,
                        self.mode)

    q_criterion_array_name = traits.String('QCriterion', enter_set=True, auto_set=False, desc=\
        r"""
        Set/Get the name of q-criterion array.
        """
    )

    def _q_criterion_array_name_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetQCriterionArrayName,
                        self.q_criterion_array_name)

    result_array_name = traits.String('Gradient', enter_set=True, auto_set=False, desc=\
        r"""
        
        """
    )

    def _result_array_name_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetResultArrayName,
                        self.result_array_name)

    vorticity_array_name = traits.String('Vorticity', enter_set=True, auto_set=False, desc=\
        r"""
        Set/Get the name of vorticity array.
        """
    )

    def _vorticity_array_name_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetVorticityArrayName,
                        self.vorticity_array_name)

    _updateable_traits_ = \
    (('compute_divergence', 'GetComputeDivergence'), ('compute_gradient',
    'GetComputeGradient'), ('compute_q_criterion',
    'GetComputeQCriterion'), ('compute_vorticity', 'GetComputeVorticity'),
    ('extensive_computation', 'GetExtensiveComputation'),
    ('abort_execute', 'GetAbortExecute'), ('release_data_flag',
    'GetReleaseDataFlag'), ('debug', 'GetDebug'),
    ('global_warning_display', 'GetGlobalWarningDisplay'),
    ('divergence_array_name', 'GetDivergenceArrayName'),
    ('gradient_array_name', 'GetGradientArrayName'), ('mode', 'GetMode'),
    ('q_criterion_array_name', 'GetQCriterionArrayName'),
    ('result_array_name', 'GetResultArrayName'), ('vorticity_array_name',
    'GetVorticityArrayName'), ('abort_output', 'GetAbortOutput'),
    ('progress_text', 'GetProgressText'), ('object_name',
    'GetObjectName'), ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['abort_execute', 'compute_divergence', 'compute_gradient',
    'compute_q_criterion', 'compute_vorticity', 'debug',
    'extensive_computation', 'global_warning_display',
    'release_data_flag', 'abort_output', 'divergence_array_name',
    'gradient_array_name', 'mode', 'object_name', 'progress_text',
    'q_criterion_array_name', 'result_array_name',
    'vorticity_array_name'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(HyperTreeGridGradient, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit HyperTreeGridGradient properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['compute_divergence', 'compute_gradient',
            'compute_q_criterion', 'compute_vorticity', 'extensive_computation'],
            [], ['abort_output', 'divergence_array_name', 'gradient_array_name',
            'mode', 'object_name', 'q_criterion_array_name', 'result_array_name',
            'vorticity_array_name']),
            title='Edit HyperTreeGridGradient properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit HyperTreeGridGradient properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

