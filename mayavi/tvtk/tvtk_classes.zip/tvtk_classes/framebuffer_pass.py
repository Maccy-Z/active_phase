# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.depth_image_processing_pass import DepthImageProcessingPass


class FramebufferPass(DepthImageProcessingPass):
    r"""
    FramebufferPass - Render into a FO
    
    Superclass: DepthImageProcessingPass
    
    @sa
    RenderPass
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkFramebufferPass, obj, update, **traits)
    
    def _get_color_texture(self):
        return wrap_vtk(self._vtk_obj.GetColorTexture())
    color_texture = traits.Property(_get_color_texture, desc=\
        r"""
        
        """
    )

    def _get_depth_texture(self):
        return wrap_vtk(self._vtk_obj.GetDepthTexture())
    depth_texture = traits.Property(_get_depth_texture, desc=\
        r"""
        
        """
    )

    def set_color_format(self, *args):
        """
        set_color_format(self, _arg:int) -> None
        C++: virtual void set_color_format(int _arg)
        Set the format to use for the color texture
        TextureObject::Float16 TextureObject::Float32 and
        TextureObject::Fixed8 are supported. Fixed8 is the default.
        """
        ret = self._wrap_call(self._vtk_obj.SetColorFormat, *args)
        return ret

    def set_depth_format(self, *args):
        """
        set_depth_format(self, _arg:int) -> None
        C++: virtual void set_depth_format(int _arg)
        Set the format to use for the depth texture e.g.
        TextureObject::Float32
        """
        ret = self._wrap_call(self._vtk_obj.SetDepthFormat, *args)
        return ret

    _updateable_traits_ = \
    (('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('active_draw_buffers',
    'GetActiveDrawBuffers'), ('object_name', 'GetObjectName'),
    ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['debug', 'global_warning_display', 'active_draw_buffers',
    'object_name'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(FramebufferPass, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit FramebufferPass properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View(([], [], ['active_draw_buffers', 'object_name']),
            title='Edit FramebufferPass properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit FramebufferPass properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

