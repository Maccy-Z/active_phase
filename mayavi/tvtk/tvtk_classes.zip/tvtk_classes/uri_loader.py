# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.object import Object


class URILoader(Object):
    r"""
    URILoader - Helper class for readers and importer that need to
    load more than one resource
    
    Superclass: Object
    
    ## Introduction
    
    `URILoader` is a class that will load URIs, giving
    `vtkresource_stream`s from resolved resource. URI logic (parsing,
    resolution) is implemented in `URI`.
    
    Some formats, such as GLTF, may refer to external resources through
    URIs. This URI loader can be used to solve this problem.
    
    `URILoader` provides "file" and "data" URIs loading. "file" URIs
    loading only supports localhost. More schemes may be supported in
    future versions.
    
    ## Base URI
    
    Base URI, specified in
    [RFC3986#5](https://datatracker.ietf.org/doc/html/rfc3986#section-5),
    is a concept that enable URIs to refer to relative resources from a
    base resource. For example, you can have a file that needs to look
    for another file next to it. The best way to implement this, is to
    have the first file as the base URI, and the referenced file as a
    relative reference.
    
    To set a local file as base URI, you should use `set_base_file_name`,
    and for a local directory, you should use `set_base_directory`. These
    functions generate a "file" URI from given path. For example, calling
    `set_base_file_name(".")` will generate the following URI:
    `"file:///<absolute-current-working-directory>/."`. These functions
    should be used because they handle some platform specific details,
    such as adding a `/` at the beginning of the path on Windows,
    percent-encoding, resolving relative paths, "." and "..", checking
    that path exists and actual filesystem entry type is coherent.
    
    If the loader has no base URI, it can only load full URIs. See
    `URI` for more informations.
    
    ## Basic usage
    
    Here is a basic exemple of `URILoader` usage: ```cpp Newloader;
    loader->set_base_file_name("."); // Set current working directory as the
    base URI // This Load call will parse the string to a URI. In that
    case, the URI only has a path. // Then it will be resolved from base
    URI. In that case, the current working directory: //
    "file:///<cwd>/." + "example.txt" == "file:///<cwd>/example.txt" //
    Then it will call the `do_load` function. This do_load function will
    check URI scheme, // here "file", and call the right loading
    function. In that case load_file will be called. // load_file will
    create a FileResourceStream and open it on URI path. auto stream =
    loader->Load("example.txt"); // stream is opened on ./example.txt...
    Or it is null, in case of error.
    
    // When loading a full URI, base URI is ignored (see URI::Resolve
    and RFC specs) auto other = loader->Load("data:;base64,AAAA"); //
    other is a MemoryResourceStream on the decoded base64 data. Here,
    3 bytes, all equal to 0. ```
    
    Note that in previous example, `loader->Load()` actually returns a
    `vtkresource_stream`, the real type can be accessed through
    `safe_down_cast`.
    
    ## Usage in readers
    
    When implementing a reader, you should use `URILoader` if the
    format can contain URIs. Here are the global guidelines of URI loader
    support in a reader:
    - The function should be named `set_uri_loader`.
    - Depending on the format, the reader may require an URI loader, or
      just optionally use it.
    - The reader may use a default constructed URI loader by default.
      This would enable full URI loading, such as "data" URIs.
    - When reading from a file name, using `set_file_name` function, the
      reader should internally open a `vtkfile_resource_stream` on the file
    and create a `URILoader` with a base URI set to `file_name`, then
      use the same code as the resource stream based reading. This
      prevents code duplication.
    
    ## Extension
    
    `URILoader::do_load` is reponsible of actually loading a full URI.
    It is a virtual function, so it can be reimplemented to let the user
    support additional schemes. In case you want do support additional
    scheme, URI scheme and host should be case-insensitive as specified
    in
    [RFC3986#6.2.2.1](https://datatracker.ietf.org/doc/html/rfc3986#sectio
    n-6.2.2.1).
    
    `URILoader::load_file` and `URILoader::load_data` are the actual
    implementation of "file" and "data" URI loading.
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkURILoader, obj, update, **traits)
    
    def _get_base_uri(self):
        return wrap_vtk(self._vtk_obj.GetBaseURI())
    def _set_base_uri(self, arg):
        old_val = self._get_base_uri()
        self._wrap_call(self._vtk_obj.SetBaseURI,
                        deref_vtk(arg))
        self.trait_property_changed('base_uri', old_val, arg)
    base_uri = traits.Property(_get_base_uri, _set_base_uri, desc=\
        r"""
        Get base URI
        @return the pointer on base URI, may be nullptr.
        """
    )

    def has_base_uri(self):
        """
        has_base_uri(self) -> bool
        C++: bool has_base_uri()
        Check if loader as a base URI
        """
        ret = self._vtk_obj.HasBaseURI()
        return ret
        

    def load(self, *args):
        """
        load(self, uri:str) -> ResourceStream
        C++: SmartPointer<vtkResourceStream> load(
            const std::string &uri)
        load(self, uri:str, size:int) -> ResourceStream
        C++: SmartPointer<vtkResourceStream> load(const char *uri,
            std::size_t size)
        load(self, uri:URI) -> ResourceStream
        C++: SmartPointer<vtkResourceStream> load(const URI *uri)
        Load a resource referenced by an URI
        
        Perform as if by calling `this->Load(uri.data(), uri.size())`.
        
        @param uri URI string representation, may be empty.
        @return A `vtkresource_stream` on the loaded resource on success,
            nullptr otherwise.
        """
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.Load, *my_args)
        return wrap_vtk(ret)

    def load_resolved(self, *args):
        """
        load_resolved(self, uri:URI) -> ResourceStream
        C++: SmartPointer<vtkResourceStream> load_resolved(
            const URI *uri)
        Load a resource from a full URI
        
        Checks if URI is suitable for loading (i.e. is a full URI), then
        calls `do_load(uri)`.
        
        @param uri A `URI`, must be a full URI
        @return A `vtkresource_stream` on the loaded resource on success,
            nullptr otherwise.
        """
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.LoadResolved, *my_args)
        return wrap_vtk(ret)

    def resolve(self, *args):
        """
        resolve(self, uri:URI) -> URI
        C++: SmartPointer<vtkURI> resolve(const URI *uri)
        Resolve URI from base URI
        @return URI::Resolve(this->GetBaseURI(), uri);
        """
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.Resolve, *my_args)
        return wrap_vtk(ret)

    def set_base_directory(self, *args):
        """
        set_base_directory(self, dirpath:str) -> bool
        C++: bool set_base_directory(const std::string &dirpath)
        Higher level way to set the base URI to an existing directory
        
        This generates a file URI on the absolute path of the specified
        directory `"."` file. `path` must refer to an existing directory.
        
        @param dirpath File path to use as base URI.
        `dirpath` may be relative, it will be automatically transformed
        into an absolute path.
        @return true if path can be resolved, false otherwise
        """
        ret = self._wrap_call(self._vtk_obj.SetBaseDirectory, *args)
        return ret

    def set_base_file_name(self, *args):
        """
        set_base_file_name(self, filepath:str) -> bool
        C++: bool set_base_file_name(const std::string &filepath)
        Higher level way to set the base URI to an existing file
        
        This generates a file URI on the absolute path of the specified
        filepath. `filepath` must refer to an existing file.
        
        @param filepath File path to use as base URI.
        `filepath` may be relative, it will be automatically transformed
        into an absolute path.
        @return true if filename can be resolved, false otherwise
        """
        ret = self._wrap_call(self._vtk_obj.SetBaseFileName, *args)
        return ret

    _updateable_traits_ = \
    (('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('object_name', 'GetObjectName'),
    ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['debug', 'global_warning_display', 'object_name'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(URILoader, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit URILoader properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View(([], [], ['object_name']),
            title='Edit URILoader properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit URILoader properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

