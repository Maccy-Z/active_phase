# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.object import Object


class HyperTreeGridLocator(Object):
    r"""
    HyperTreeGridLocator - abstract base class for objects that
    implement accelerated searches through hyper_tree
    
    Superclass: Object
    
    Grids (HTGs)
    
    The goal of this abstract class is to define an interface to helper
    objects that implement optimized search methods through
    HyperTreeGrids. This class is heavily inspired from the Locator
    interface but constructed to be compatible with HyperTreeGrids
    (which are not DataSets at the time of this implementation).
    Ideally, implementations of this interface leverage the specific
    structure of hyper_trees and hyper_tree_grids to deliver accelerated
    search algorithms through their data.
    
    As a side comment: ideally we would inherit from Locator which
    only supports DataSets right now. Hopefully in the future
    HyperTreeGrid will become a DataSet or CompositeDataSet and
    we could accomplish just that with minimal refactoring.
    
    @sa
    HyperTreeGrid, HyperTree, HyperTreeGridOrientedCursor,
    HyperTreeGridNonOrientedCursor
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkHyperTreeGridLocator, obj, update, **traits)
    
    def _get_htg(self):
        return wrap_vtk(self._vtk_obj.GetHTG())
    def _set_htg(self, arg):
        old_val = self._get_htg()
        self._wrap_call(self._vtk_obj.SetHTG,
                        deref_vtk(arg))
        self.trait_property_changed('htg', old_val, arg)
    htg = traits.Property(_get_htg, _set_htg, desc=\
        r"""
        Getter/Setter methods for setting the HyperTreeGrid
        """
    )

    tolerance = traits.Float(0.0, enter_set=True, auto_set=False, desc=\
        r"""
        Get/Set tolerance used when searching for cells in the HTG.
        Default is 0.0
        """
    )

    def _tolerance_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetTolerance,
                        self.tolerance)

    def find_cell(self, *args):
        """
        find_cell(self, point:(float, float, float), tol:float,
            cell:GenericCell, subId:int, pcoords:[float, float, float],
             weights:[float, ...]) -> int
        C++: virtual IdType find_cell(const double point[3], double tol,
             GenericCell *cell, int &subId, double pcoords[3],
            double *weights)
        Pure virtual. Find the cell where a given point lies
        @param[in] point an array holding the coordinates of the point to
        search for
        @param[in] tol tolerance level
        @param[out] cell pointer to a cell configured with information
            from return value cell index
        @param[out] subId index of the sub cell if composite cell
        @param[out] pcoords parametric coordinates of the point in the
            cell
        @param[out] weights interpolation weights of the sought point in
            the cell
        @return the global index of the cell holding the point (-1 if no
            cell is found or masked)
        """
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.FindCell, *my_args)
        return ret

    def initialize(self):
        """
        initialize(self) -> None
        C++: virtual void initialize()
        Initialize or reinitialize the locator (setting or re-setting
        clean objects in memory) (Does nothing)
        """
        ret = self._vtk_obj.Initialize()
        return ret
        

    def intersect_with_line(self, *args):
        """
        intersect_with_line(self, p0:(float, float, float), p1:(float,
            float, float), tol:float, t:float, x:[float, float, float],
            pcoords:[float, float, float], subId:int, cellId:int,
            cell:GenericCell) -> int
        C++: virtual int intersect_with_line(const double p0[3],
            const double p1[3], double tol, double &t, double x[3],
            double pcoords[3], int &subId, IdType &cellId,
            GenericCell *cell)
        intersect_with_line(self, p0:(float, float, float), p1:(float,
            float, float), tol:float, points:Points, cellIds:IdList,
             cell:GenericCell) -> int
        C++: virtual int intersect_with_line(const double p0[3],
            const double p1[3], double tol, Points *points,
            IdList *cellIds, GenericCell *cell)
        Pure virtual. Find first intersection of the line defined by (p0,
        p1) with the HTG
        @param[in] p0 first point of the line
        @param[in] p1 second point of the line
        @param[in] tol tolerance level
        @param[out] t pseudo-time along line path at intersection
        @param[out] x intersection point
        @param[out] pcoords parametric coordinatesof intersection
        @param[out] subId index of the sub cell if composite cell
        @param[out] cellId the global index of the intersected cell
        @param[out] cell pointer to a Cell object corresponding to
            cellId
        @return an integer with 0 if no intersection could be found
        """
        my_args = deref_array(args, [(('float', 'float', 'float'), ('float', 'float', 'float'), 'float', 'float', ['float', 'float', 'float'], ['float', 'float', 'float'], 'int', 'int', 'vtkGenericCell'), (('float', 'float', 'float'), ('float', 'float', 'float'), 'float', 'vtkPoints', 'vtkIdList', 'vtkGenericCell')])
        ret = self._wrap_call(self._vtk_obj.IntersectWithLine, *my_args)
        return ret

    def search(self, *args):
        """
        search(self, point:(float, float, float)) -> int
        C++: virtual IdType search(const double point[3])
        Basic search for cell holding a given point
        @param point coordinated of sought point
        @return the global index of the cell holding the point (-1 if
            cell not found or masked)
        """
        ret = self._wrap_call(self._vtk_obj.Search, *args)
        return ret

    def update(self):
        """
        update(self) -> None
        C++: virtual void update()
        Update the locator's internal variables with respect to changes
        that could have happened outside.
        """
        ret = self._vtk_obj.Update()
        return ret
        

    _updateable_traits_ = \
    (('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('tolerance', 'GetTolerance'),
    ('object_name', 'GetObjectName'), ('reference_count',
    'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['debug', 'global_warning_display', 'object_name', 'tolerance'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(HyperTreeGridLocator, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit HyperTreeGridLocator properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View(([], [], ['object_name', 'tolerance']),
            title='Edit HyperTreeGridLocator properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit HyperTreeGridLocator properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

