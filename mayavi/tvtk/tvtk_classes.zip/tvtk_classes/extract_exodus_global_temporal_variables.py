# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.table_algorithm import TableAlgorithm


class ExtractExodusGlobalTemporalVariables(TableAlgorithm):
    r"""
    ExtractExodusGlobalTemporalVariables - extract global temporal
    arrays or suitable field data arrays
    
    Superclass: TableAlgorithm
    
    ExtractExodusGlobalTemporalVariables extracts field data arrays
    that it determines to represent temporal quantities. This
    determination is done as follows:
    
    * If `auto_detect_global_temporal_data_arrays` is true, it checks if to
      see if the field data has any array with a key named
      "GLOBAL_TEMPORAL_VARIABLE". If found, only arrays with this key are
    extracted.
    * If such an array is not found, or if
      `auto_detect_global_temporal_data_arrays` is false, then all arrays with
    single tuple are extracted.
    
    If an array has GLOBAL_TEMPORAL_VARIABLE key in its information, it
    means that the array has multiple tuples each associated with the
    specific timestep. This was pattern first introduced in
    `vtkexodus_ii_reader` and hence the name for this class. This class was
    originally only intended to extract such arrays. It has since been
    expanded to support other arrays in field data.
    
    If the number of tuples in a GLOBAL_TEMPORAL_VARIABLE array is less
    than the number of timesteps, we assume that we are dealing with
    restarted files and hence update the pipeline appropriately to
    request the remaining tuples iteratively.
    
    For arrays without GLOBAL_TEMPORAL_VARIABLE, we always iterate over
    all input timesteps one at a time and accumulate the results.
    
    @sa ExodusIIReader, ExodusIIReader::GLOBAL_TEMPORAL_VARIABLE.
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkExtractExodusGlobalTemporalVariables, obj, update, **traits)
    
    auto_detect_global_temporal_data_arrays = tvtk_base.true_bool_trait(desc=\
        r"""
        When set to true (default) this filter will check if any of the
        arrays in the input field data has a key named
        `GLOBAL_TEMPORAL_VARIABLE`. If so, this filter will only extract
        those arrays. If no such array is found, then all single-tuple
        arrays are extracted. Set this to false to disable this
        auto-detection and simply extract all single-tuple arrays.
        
        @sa `vtkexodus_ii_reader::GLOBAL_TEMPORAL_VARIABLE`
        """
    )

    def _auto_detect_global_temporal_data_arrays_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetAutoDetectGlobalTemporalDataArrays,
                        self.auto_detect_global_temporal_data_arrays_)

    _updateable_traits_ = \
    (('auto_detect_global_temporal_data_arrays',
    'GetAutoDetectGlobalTemporalDataArrays'), ('abort_execute',
    'GetAbortExecute'), ('release_data_flag', 'GetReleaseDataFlag'),
    ('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('abort_output', 'GetAbortOutput'),
    ('progress_text', 'GetProgressText'), ('object_name',
    'GetObjectName'), ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['abort_execute', 'auto_detect_global_temporal_data_arrays', 'debug',
    'global_warning_display', 'release_data_flag', 'abort_output',
    'object_name', 'progress_text'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(ExtractExodusGlobalTemporalVariables, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit ExtractExodusGlobalTemporalVariables properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['auto_detect_global_temporal_data_arrays'], [],
            ['abort_output', 'object_name']),
            title='Edit ExtractExodusGlobalTemporalVariables properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit ExtractExodusGlobalTemporalVariables properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

