# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.unstructured_grid_algorithm import UnstructuredGridAlgorithm


class Nek5000Reader(UnstructuredGridAlgorithm):
    r"""
    Nek5000Reader - Reads Nek5000 format data files.
    
    Superclass: UnstructuredGridAlgorithm
    
    @par Thanks: This class was developed by  Jean Favre (jfavre@cscs.ch)
    from the Swiss National Supercomputing Centre
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkNek5000Reader, obj, update, **traits)
    
    clean_grid = tvtk_base.false_bool_trait(desc=\
        r"""
        used for para_view to decide if cleaning the grid to merge points
        """
    )

    def _clean_grid_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetCleanGrid,
                        self.clean_grid_)

    spectral_element_ids = tvtk_base.false_bool_trait(desc=\
        r"""
        used for para_view to decide if showing the spectral elements ids
        as cell-data
        """
    )

    def _spectral_element_ids_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetSpectralElementIds,
                        self.spectral_element_ids_)

    data_file_name = tvtk_base.vtk_file_name("", desc=\
        r"""
        
        """
    )

    def _data_file_name_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetDataFileName,
                        self.data_file_name)

    file_name = tvtk_base.vtk_file_name("", desc=\
        r"""
        
        """
    )

    def _file_name_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetFileName,
                        self.file_name)

    def get_point_array_status(self, *args):
        """
        get_point_array_status(self, name:str) -> bool
        C++: bool get_point_array_status(const char *name)
        get_point_array_status(self, index:int) -> bool
        C++: bool get_point_array_status(int index)
        Get/Set whether the point array with the given name or index is
        to be read.
        """
        ret = self._wrap_call(self._vtk_obj.GetPointArrayStatus, *args)
        return ret

    def set_point_array_status(self, *args):
        """
        set_point_array_status(self, name:str, status:int) -> None
        C++: void set_point_array_status(const char *name, int status)"""
        ret = self._wrap_call(self._vtk_obj.SetPointArrayStatus, *args)
        return ret

    time_step_range = traits.Array(enter_set=True, auto_set=False, shape=(2,), dtype="int", value=(0, 0), cols=2, desc=\
        r"""
        
        """
    )

    def _time_step_range_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetTimeStepRange,
                        self.time_step_range)

    def _get_input(self):
        try:
            return wrap_vtk(self._vtk_obj.GetInput(0))
        except TypeError:
            return wrap_vtk(self._vtk_obj.GetInput())
    input = traits.Property(_get_input,
                            desc="The first input of this object, i.e. the result of `get_input(0)`.")
    
    def get_input(self, *args):
        """
        get_input(self, port:int) -> DataObject
        C++: DataObject *get_input(int port)
        get_input(self) -> DataObject
        C++: DataObject *get_input()"""
        ret = self._wrap_call(self._vtk_obj.GetInput, *args)
        return wrap_vtk(ret)

    def _get_number_of_point_arrays(self):
        return self._vtk_obj.GetNumberOfPointArrays()
    number_of_point_arrays = traits.Property(_get_number_of_point_arrays, desc=\
        r"""
        Get the number of point arrays available in the input.
        """
    )

    def _get_number_of_time_steps(self):
        return self._vtk_obj.GetNumberOfTimeSteps()
    number_of_time_steps = traits.Property(_get_number_of_time_steps, desc=\
        r"""
        
        """
    )

    def get_point_array_name(self, *args):
        """
        get_point_array_name(self, index:int) -> str
        C++: const char *get_point_array_name(int index)
        Get the name of the  point array with the given index in the
        input.
        """
        ret = self._wrap_call(self._vtk_obj.GetPointArrayName, *args)
        return ret

    def get_variable_names_from_data(self, *args):
        """
        get_variable_names_from_data(self, varTags:str) -> int
        C++: size_t get_variable_names_from_data(char *varTags)
        Get the names of variables stored in the data
        """
        ret = self._wrap_call(self._vtk_obj.GetVariableNamesFromData, *args)
        return ret

    def can_read_file(self, *args):
        """
        can_read_file(self, fname:str) -> int
        C++: int can_read_file(const char *fname)"""
        ret = self._wrap_call(self._vtk_obj.CanReadFile, *args)
        return ret

    def disable_all_point_arrays(self):
        """
        disable_all_point_arrays(self) -> None
        C++: void disable_all_point_arrays()
        Turn on/off all point arrays.
        """
        ret = self._vtk_obj.DisableAllPointArrays()
        return ret
        

    def enable_all_point_arrays(self):
        """
        enable_all_point_arrays(self) -> None
        C++: void enable_all_point_arrays()"""
        ret = self._vtk_obj.EnableAllPointArrays()
        return ret
        

    _updateable_traits_ = \
    (('clean_grid', 'GetCleanGrid'), ('spectral_element_ids',
    'GetSpectralElementIds'), ('abort_execute', 'GetAbortExecute'),
    ('release_data_flag', 'GetReleaseDataFlag'), ('debug', 'GetDebug'),
    ('global_warning_display', 'GetGlobalWarningDisplay'),
    ('data_file_name', 'GetDataFileName'), ('file_name', 'GetFileName'),
    ('time_step_range', 'GetTimeStepRange'), ('abort_output',
    'GetAbortOutput'), ('progress_text', 'GetProgressText'),
    ('object_name', 'GetObjectName'), ('reference_count',
    'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['abort_execute', 'clean_grid', 'debug', 'global_warning_display',
    'release_data_flag', 'spectral_element_ids', 'abort_output',
    'data_file_name', 'file_name', 'object_name', 'progress_text',
    'time_step_range'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(Nek5000Reader, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit Nek5000Reader properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['clean_grid', 'spectral_element_ids'], [], ['abort_output',
            'data_file_name', 'file_name', 'object_name', 'time_step_range']),
            title='Edit Nek5000Reader properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit Nek5000Reader properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

