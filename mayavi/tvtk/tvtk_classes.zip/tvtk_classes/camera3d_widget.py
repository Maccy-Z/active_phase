# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.abstract_widget import AbstractWidget


class Camera3DWidget(AbstractWidget):
    r"""
    Camera3DWidget - 3D Widget for manipulating a Camera
    
    Superclass: AbstractWidget
    
    This 3D widget interacts with a Camera3DRepresentation class
    (i.e., it handles the events that drive its corresponding
    representation). A nice feature of Camera3DWidget, like any 3D
    widget, will work with the current interactor style. That is, if
    Camera3DWidget does not handle an event, then all other registered
    observers (including the interactor style) have an opportunity to
    process the event. Otherwise, the Camera3DWidget will terminate
    the processing of the event that it handles.
    
    To use this widget, you pair it with a Camera3DRepresentation (or
    a subclass). Various options are available in the representation for
    controlling how the widget appears, and how the widget functions.
    
    @par Mouse Event Bindings: By default, the widget responds to the
    following VTK events (i.e., it watches the RenderWindowInteractor
    for these events):
    
    Select and move the camera box to change the camera position. Select
    and move the camera cone to change the camera view angle. Select and
    move the sphere handles to change the target and view up. 
    
    @par Key Event Bindings: By default, the widget responds to the
    following key pressed event:
    
    'x' or 'X': set the translation constrainted to X axis, or None if
    already set to X. 'y' or 'Y': set the translation constrainted to Y
    axis, or None if already set to Y. 'z' or 'Z': set the translation
    constrainted to Z axis, or None if already set to Z. 'o' or 'O':
    remove any translation constraint. 'a' or 'A': toggle translation of
    both position and target, or only one at a time. 'c' or 'C': toggle
    frustum visibility. 
    
    @warning
    This class, and Camera3DRepresentation, are second generation VTK
    widgets.
    
    @sa
    Camera3DRepresentation
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkCamera3DWidget, obj, update, **traits)
    
    def _get_representation(self):
        return wrap_vtk(self._vtk_obj.GetRepresentation())
    def _set_representation(self, arg):
        old_val = self._get_representation()
        self._wrap_call(self._vtk_obj.SetRepresentation,
                        deref_vtk(arg))
        self.trait_property_changed('representation', old_val, arg)
    representation = traits.Property(_get_representation, _set_representation, desc=\
        r"""
        Return an instance of WidgetRepresentation used to represent
        this widget in the scene. Note that the representation is a
        subclass of Prop (typically a subclass of
        WidgetRepresentation) so it can be added to the renderer
        independent of the widget.
        """
    )

    _updateable_traits_ = \
    (('manages_cursor', 'GetManagesCursor'), ('process_events',
    'GetProcessEvents'), ('enabled', 'GetEnabled'),
    ('key_press_activation', 'GetKeyPressActivation'), ('picking_managed',
    'GetPickingManaged'), ('debug', 'GetDebug'),
    ('global_warning_display', 'GetGlobalWarningDisplay'), ('priority',
    'GetPriority'), ('key_press_activation_value',
    'GetKeyPressActivationValue'), ('object_name', 'GetObjectName'),
    ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['debug', 'enabled', 'global_warning_display',
    'key_press_activation', 'manages_cursor', 'picking_managed',
    'process_events', 'key_press_activation_value', 'object_name',
    'priority'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(Camera3DWidget, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit Camera3DWidget properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['enabled', 'key_press_activation', 'manages_cursor',
            'picking_managed', 'process_events'], [],
            ['key_press_activation_value', 'object_name', 'priority']),
            title='Edit Camera3DWidget properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit Camera3DWidget properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

