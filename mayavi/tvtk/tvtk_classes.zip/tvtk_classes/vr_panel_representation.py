# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.widget_representation import WidgetRepresentation


class VRPanelRepresentation(WidgetRepresentation):
    r"""
    VRPanelRepresentation - Widget representation for VRPanelWidget
    
    Superclass: WidgetRepresentation
    
    Implementation of the popup panel representation for the
    VRPanelWidget. This representation is rebuilt every time the
    hovered prop changes. Its position is set according to the camera
    orientation and is placed at a distance defined in meters in the
    build_representation() method.
    
    WARNING: The panel might be occluded by other props.
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkVRPanelRepresentation, obj, update, **traits)
    
    allow_adjustment = tvtk_base.true_bool_trait(desc=\
        r"""
        Can the panel be relocated by the user
        """
    )

    def _allow_adjustment_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetAllowAdjustment,
                        self.allow_adjustment_)

    def _get_text_actor(self):
        return wrap_vtk(self._vtk_obj.GetTextActor())
    text_actor = traits.Property(_get_text_actor, desc=\
        r"""
        
        """
    )

    def place_widget_extended(self, *args):
        """
        place_widget_extended(self, bounds:(float, ...), normal:(float, ...)
            , upvec:(float, ...), scale:float) -> None
        C++: void place_widget_extended(const double *bounds,
            const double *normal, const double *upvec, double scale)"""
        ret = self._wrap_call(self._vtk_obj.PlaceWidgetExtended, *args)
        return ret

    def set_coordinate_system_to_hmd(self):
        """
        set_coordinate_system_to_hmd(self) -> None
        C++: void set_coordinate_system_to_hmd()"""
        ret = self._vtk_obj.SetCoordinateSystemToHMD()
        return ret
        

    def set_coordinate_system_to_left_controller(self):
        """
        set_coordinate_system_to_left_controller(self) -> None
        C++: void set_coordinate_system_to_left_controller()"""
        ret = self._vtk_obj.SetCoordinateSystemToLeftController()
        return ret
        

    def set_coordinate_system_to_right_controller(self):
        """
        set_coordinate_system_to_right_controller(self) -> None
        C++: void set_coordinate_system_to_right_controller()"""
        ret = self._vtk_obj.SetCoordinateSystemToRightController()
        return ret
        

    def set_coordinate_system_to_world(self):
        """
        set_coordinate_system_to_world(self) -> None
        C++: void set_coordinate_system_to_world()"""
        ret = self._vtk_obj.SetCoordinateSystemToWorld()
        return ret
        

    def set_text(self, *args):
        """
        set_text(self, str:str) -> None
        C++: void set_text(const char *str)
        Set panel text
        """
        ret = self._wrap_call(self._vtk_obj.SetText, *args)
        return ret

    _updateable_traits_ = \
    (('allow_adjustment', 'GetAllowAdjustment'), ('need_to_render',
    'GetNeedToRender'), ('picking_managed', 'GetPickingManaged'),
    ('dragable', 'GetDragable'), ('pickable', 'GetPickable'),
    ('use_bounds', 'GetUseBounds'), ('visibility', 'GetVisibility'),
    ('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('handle_size', 'GetHandleSize'),
    ('place_factor', 'GetPlaceFactor'), ('estimated_render_time',
    'GetEstimatedRenderTime'), ('render_time_multiplier',
    'GetRenderTimeMultiplier'), ('object_name', 'GetObjectName'),
    ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['allow_adjustment', 'debug', 'dragable', 'global_warning_display',
    'need_to_render', 'pickable', 'picking_managed', 'use_bounds',
    'visibility', 'estimated_render_time', 'handle_size', 'object_name',
    'place_factor', 'render_time_multiplier'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(VRPanelRepresentation, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit VRPanelRepresentation properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['allow_adjustment', 'need_to_render', 'picking_managed',
            'use_bounds', 'visibility'], [], ['estimated_render_time',
            'handle_size', 'object_name', 'place_factor',
            'render_time_multiplier']),
            title='Edit VRPanelRepresentation properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit VRPanelRepresentation properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

