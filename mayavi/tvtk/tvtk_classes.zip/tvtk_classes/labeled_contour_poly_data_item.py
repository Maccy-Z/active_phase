# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.poly_data_item import PolyDataItem


class LabeledContourPolyDataItem(PolyDataItem):
    r"""
    LabeledContourPolyDataItem - Filter that translate a PolyData
    2D mesh into ContextItems.
    
    Superclass: PolyDataItem
    
    @warning
    The input PolyData should be a 2D mesh.
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkLabeledContourPolyDataItem, obj, update, **traits)
    
    label_visibility = tvtk_base.true_bool_trait(desc=\
        r"""
        If true, labels will be placed and drawn during rendering.
        Otherwise, only the mapper returned by get_poly_data_mapper() will
        be rendered. The default is to draw labels.
        """
    )

    def _label_visibility_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetLabelVisibility,
                        self.label_visibility_)

    skip_distance = traits.Float(0.0, enter_set=True, auto_set=False, desc=\
        r"""
        Ensure that there are at least skip_distance pixels between
        labels. This is only enforced on labels along the same line. The
        default is 0.
        """
    )

    def _skip_distance_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetSkipDistance,
                        self.skip_distance)

    def _get_text_properties(self):
        return wrap_vtk(self._vtk_obj.GetTextProperties())
    def _set_text_properties(self, arg):
        old_val = self._get_text_properties()
        self._wrap_call(self._vtk_obj.SetTextProperties,
                        deref_vtk(arg))
        self.trait_property_changed('text_properties', old_val, arg)
    text_properties = traits.Property(_get_text_properties, _set_text_properties, desc=\
        r"""
        
        """
    )

    def _get_text_property_mapping(self):
        return wrap_vtk(self._vtk_obj.GetTextPropertyMapping())
    def _set_text_property_mapping(self, arg):
        old_val = self._get_text_property_mapping()
        my_arg = deref_array([arg], [['vtkDoubleArray']])
        self._wrap_call(self._vtk_obj.SetTextPropertyMapping,
                        my_arg[0])
        self.trait_property_changed('text_property_mapping', old_val, arg)
    text_property_mapping = traits.Property(_get_text_property_mapping, _set_text_property_mapping, desc=\
        r"""
        Values in this array correspond to TextProperty objects in the
        text_properties collection. If a contour line's scalar value
        exists in this array, the corresponding text property is used for
        the label. See set_text_properties for more information.
        """
    )

    def set_text_property(self, *args):
        """
        set_text_property(self, tprop:TextProperty) -> None
        C++: virtual void set_text_property(TextProperty *tprop)
        The text property used to label the lines. Note that both
        vertical and horizontal justifications will be reset to
        "Centered" prior to rendering.
        
        ote This is a convenience method that clears text_properties and
        inserts the argument as the only property in the collection.
        @sa set_text_properties
        """
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.SetTextProperty, *my_args)
        return ret

    _updateable_traits_ = \
    (('label_visibility', 'GetLabelVisibility'), ('debug', 'GetDebug'),
    ('global_warning_display', 'GetGlobalWarningDisplay'),
    ('skip_distance', 'GetSkipDistance'), ('opacity', 'GetOpacity'),
    ('interactive', 'GetInteractive'), ('visible', 'GetVisible'),
    ('object_name', 'GetObjectName'), ('reference_count',
    'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['debug', 'global_warning_display', 'label_visibility',
    'interactive', 'object_name', 'opacity', 'skip_distance', 'visible'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(LabeledContourPolyDataItem, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit LabeledContourPolyDataItem properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['label_visibility'], [], ['interactive', 'object_name',
            'opacity', 'skip_distance', 'visible']),
            title='Edit LabeledContourPolyDataItem properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit LabeledContourPolyDataItem properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

