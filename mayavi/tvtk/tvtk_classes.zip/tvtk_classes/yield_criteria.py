# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.data_set_algorithm import DataSetAlgorithm


class YieldCriteria(DataSetAlgorithm):
    r"""
    YieldCriteria - Compute principal stress and yield criteria from
    symmetric tensor
    
    Superclass: DataSetAlgorithm
    
    This filter computes various yield criteria from symmetric tensors
    including:
    - Principal stress values and vectors
    - Tresca criterion
    - Von Mises criterion
    
    The principal values are ordered from largest to smallest.
    - sigmaN value: Nth principal stress eigenvalue
    - sigmaN vector: Nth principal stress vector (can be scaled with the
      value)
    - Tresca criterion : |sigma3 - sigma1|
    - Von Mises criterion: sqrt( (sigma1 - sigma2)^2 + (sigma2 -
      sigma3)^2 + (sigma1 - sigma3)^2 ) / sqrt(2)
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkYieldCriteria, obj, update, **traits)
    
    scale_vectors = traits.Bool(False, enter_set=True, auto_set=False, desc=\
        r"""
        
        """
    )

    def _scale_vectors_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetScaleVectors,
                        self.scale_vectors)

    def _get_cell_data_array_selection(self):
        return wrap_vtk(self._vtk_obj.GetCellDataArraySelection())
    cell_data_array_selection = traits.Property(_get_cell_data_array_selection, desc=\
        r"""
        Access the cell data array selection that specifies which cell
        data arrays should have their yield criteria computed.
        """
    )

    def _get_criteria_selection(self):
        return wrap_vtk(self._vtk_obj.GetCriteriaSelection())
    criteria_selection = traits.Property(_get_criteria_selection, desc=\
        r"""
        Access the selection of yield criteria to compute.
        """
    )

    def _get_input(self):
        return wrap_vtk(self._vtk_obj.GetInput())
    input = traits.Property(_get_input, desc=\
        r"""
        Get the input data object. This method is not recommended for
        use, but lots of old style filters use it.
        """
    )

    def _get_point_data_array_selection(self):
        return wrap_vtk(self._vtk_obj.GetPointDataArraySelection())
    point_data_array_selection = traits.Property(_get_point_data_array_selection, desc=\
        r"""
        Access the point data array selection that specifies which point
        data arrays should have their yield criteria computed.
        """
    )

    _updateable_traits_ = \
    (('abort_execute', 'GetAbortExecute'), ('release_data_flag',
    'GetReleaseDataFlag'), ('debug', 'GetDebug'),
    ('global_warning_display', 'GetGlobalWarningDisplay'),
    ('scale_vectors', 'GetScaleVectors'), ('abort_output',
    'GetAbortOutput'), ('progress_text', 'GetProgressText'),
    ('object_name', 'GetObjectName'), ('reference_count',
    'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['abort_execute', 'debug', 'global_warning_display',
    'release_data_flag', 'abort_output', 'object_name', 'progress_text',
    'scale_vectors'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(YieldCriteria, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit YieldCriteria properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View(([], [], ['abort_output', 'object_name', 'scale_vectors']),
            title='Edit YieldCriteria properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit YieldCriteria properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

