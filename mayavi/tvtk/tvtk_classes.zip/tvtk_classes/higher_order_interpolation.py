# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.object import Object


class HigherOrderInterpolation(Object):
    r"""
    HigherOrderInterpolation
    
    Superclass: Object
    
    See Also:
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkHigherOrderInterpolation, obj, update, **traits)
    
    def get_edge_indices_bounding_hex_face(self, *args):
        """
        get_edge_indices_bounding_hex_face(faceId:int) -> (int, int, int, int)
        C++: static const int *get_edge_indices_bounding_hex_face(int faceId)"""
        ret = self._wrap_call(self._vtk_obj.GetEdgeIndicesBoundingHexFace, *args)
        return ret

    def get_edge_indices_bounding_wedge_face(self, *args):
        """
        get_edge_indices_bounding_wedge_face(faceId:int) -> (int, int, int,
            int)
        C++: static const int *get_edge_indices_bounding_wedge_face(int faceId)"""
        ret = self._wrap_call(self._vtk_obj.GetEdgeIndicesBoundingWedgeFace, *args)
        return ret

    def get_fixed_parameter_of_hex_face(self, *args):
        """
        get_fixed_parameter_of_hex_face(faceId:int) -> int
        C++: static int get_fixed_parameter_of_hex_face(int faceId)"""
        ret = self._wrap_call(self._vtk_obj.GetFixedParameterOfHexFace, *args)
        return ret

    def get_fixed_parameter_of_wedge_face(self, *args):
        """
        get_fixed_parameter_of_wedge_face(faceId:int) -> int
        C++: static int get_fixed_parameter_of_wedge_face(int faceId)"""
        ret = self._wrap_call(self._vtk_obj.GetFixedParameterOfWedgeFace, *args)
        return ret

    def get_fixed_parameters_of_hex_edge(self, *args):
        """
        get_fixed_parameters_of_hex_edge(edgeId:int) -> Vector2i
        C++: static Vector2i get_fixed_parameters_of_hex_edge(int edgeId)"""
        ret = self._wrap_call(self._vtk_obj.GetFixedParametersOfHexEdge, *args)
        return wrap_vtk(ret)

    def get_fixed_parameters_of_wedge_edge(self, *args):
        """
        get_fixed_parameters_of_wedge_edge(edgeId:int) -> Vector2i
        C++: static Vector2i get_fixed_parameters_of_wedge_edge(int edgeId)"""
        ret = self._wrap_call(self._vtk_obj.GetFixedParametersOfWedgeEdge, *args)
        return wrap_vtk(ret)

    def get_parametric_hex_coordinates(self, *args):
        """
        get_parametric_hex_coordinates(vertexId:int) -> Vector3d
        C++: static Vector3d get_parametric_hex_coordinates(int vertexId)"""
        ret = self._wrap_call(self._vtk_obj.GetParametricHexCoordinates, *args)
        return wrap_vtk(ret)

    def get_parametric_wedge_coordinates(self, *args):
        """
        get_parametric_wedge_coordinates(vertexId:int) -> Vector3d
        C++: static Vector3d get_parametric_wedge_coordinates(
            int vertexId)"""
        ret = self._wrap_call(self._vtk_obj.GetParametricWedgeCoordinates, *args)
        return wrap_vtk(ret)

    def get_point_indices_bounding_hex_edge(self, *args):
        """
        get_point_indices_bounding_hex_edge(edgeId:int) -> Vector2i
        C++: static Vector2i get_point_indices_bounding_hex_edge(int edgeId)"""
        ret = self._wrap_call(self._vtk_obj.GetPointIndicesBoundingHexEdge, *args)
        return wrap_vtk(ret)

    def get_point_indices_bounding_hex_face(self, *args):
        """
        get_point_indices_bounding_hex_face(faceId:int) -> (int, int, int, int)
        C++: static const int *get_point_indices_bounding_hex_face(int faceId)"""
        ret = self._wrap_call(self._vtk_obj.GetPointIndicesBoundingHexFace, *args)
        return ret

    def get_point_indices_bounding_wedge_edge(self, *args):
        """
        get_point_indices_bounding_wedge_edge(edgeId:int) -> Vector2i
        C++: static Vector2i get_point_indices_bounding_wedge_edge(
            int edgeId)"""
        ret = self._wrap_call(self._vtk_obj.GetPointIndicesBoundingWedgeEdge, *args)
        return wrap_vtk(ret)

    def get_point_indices_bounding_wedge_face(self, *args):
        """
        get_point_indices_bounding_wedge_face(faceId:int) -> (int, int, int,
            int)
        C++: static const int *get_point_indices_bounding_wedge_face(
            int faceId)"""
        ret = self._wrap_call(self._vtk_obj.GetPointIndicesBoundingWedgeFace, *args)
        return ret

    def get_varying_parameter_of_hex_edge(self, *args):
        """
        get_varying_parameter_of_hex_edge(edgeId:int) -> int
        C++: static int get_varying_parameter_of_hex_edge(int edgeId)"""
        ret = self._wrap_call(self._vtk_obj.GetVaryingParameterOfHexEdge, *args)
        return ret

    def get_varying_parameter_of_wedge_edge(self, *args):
        """
        get_varying_parameter_of_wedge_edge(edgeId:int) -> int
        C++: static int get_varying_parameter_of_wedge_edge(int edgeId)"""
        ret = self._wrap_call(self._vtk_obj.GetVaryingParameterOfWedgeEdge, *args)
        return ret

    def get_varying_parameters_of_hex_face(self, *args):
        """
        get_varying_parameters_of_hex_face(faceId:int) -> Vector2i
        C++: static Vector2i get_varying_parameters_of_hex_face(int faceId)"""
        ret = self._wrap_call(self._vtk_obj.GetVaryingParametersOfHexFace, *args)
        return wrap_vtk(ret)

    def get_varying_parameters_of_wedge_face(self, *args):
        """
        get_varying_parameters_of_wedge_face(faceId:int) -> Vector2i
        C++: static Vector2i get_varying_parameters_of_wedge_face(
            int faceId)"""
        ret = self._wrap_call(self._vtk_obj.GetVaryingParametersOfWedgeFace, *args)
        return wrap_vtk(ret)

    def append_curve_collocation_points(self, *args):
        """
        append_curve_collocation_points(pts:Points, order:(int)) -> None
        C++: static void append_curve_collocation_points(
            SmartPointer<vtkPoints> &pts, const int order[1])"""
        my_args = deref_array(args, [('vtkPoints', 'int')])
        ret = self._wrap_call(self._vtk_obj.AppendCurveCollocationPoints, *my_args)
        return ret

    def append_hexahedron_collocation_points(self, *args):
        """
        append_hexahedron_collocation_points(pts:Points, order:(int, int,
            int)) -> None
        C++: static void append_hexahedron_collocation_points(
            SmartPointer<vtkPoints> &pts, const int order[3])"""
        my_args = deref_array(args, [('vtkPoints', ('int', 'int', 'int'))])
        ret = self._wrap_call(self._vtk_obj.AppendHexahedronCollocationPoints, *my_args)
        return ret

    def append_quadrilateral_collocation_points(self, *args):
        """
        append_quadrilateral_collocation_points(pts:Points, order:(int,
            int)) -> None
        C++: static void append_quadrilateral_collocation_points(
            SmartPointer<vtkPoints> &pts, const int order[2])"""
        my_args = deref_array(args, [('vtkPoints', ('int', 'int'))])
        ret = self._wrap_call(self._vtk_obj.AppendQuadrilateralCollocationPoints, *my_args)
        return ret

    def append_wedge_collocation_points(self, *args):
        """
        append_wedge_collocation_points(pts:Points, order:(int, int, int))
             -> None
        C++: static void append_wedge_collocation_points(
            SmartPointer<vtkPoints> &pts, const int order[3])"""
        my_args = deref_array(args, [('vtkPoints', ('int', 'int', 'int'))])
        ret = self._wrap_call(self._vtk_obj.AppendWedgeCollocationPoints, *my_args)
        return ret

    def tensor3_evaluate_derivative(self, *args):
        """
        tensor3_evaluate_derivative(self, order:(int, int, int), pcoords:(
            float, ...), points:Points, fieldVals:(float, ...),
            fieldDim:int, fieldDerivs:[float, ...]) -> None
        C++: virtual void tensor3_evaluate_derivative(const int order[3],
            const double *pcoords, Points *points,
            const double *fieldVals, int fieldDim, double *fieldDerivs)"""
        my_args = deref_array(args, [(('int', 'int', 'int'), ('float', Ellipsis), 'vtkPoints', ('float', Ellipsis), 'int', 'tuple')])
        ret = self._wrap_call(self._vtk_obj.Tensor3EvaluateDerivative, *my_args)
        return ret

    def wedge_evaluate(self, *args):
        """
        wedge_evaluate(self, order:(int, int, int), numberOfPoints:int,
            pcoords:(float, ...), fieldVals:[float, ...], fieldDim:int,
            fieldAtPCoords:[float, ...]) -> None
        C++: virtual void wedge_evaluate(const int order[3],
            IdType numberOfPoints, const double *pcoords,
            double *fieldVals, int fieldDim, double *fieldAtPCoords)"""
        ret = self._wrap_call(self._vtk_obj.WedgeEvaluate, *args)
        return ret

    def wedge_evaluate_derivative(self, *args):
        """
        wedge_evaluate_derivative(self, order:(int, int, int), pcoords:(
            float, ...), points:Points, fieldVals:(float, ...),
            fieldDim:int, fieldDerivs:[float, ...]) -> None
        C++: virtual void wedge_evaluate_derivative(const int order[3],
            const double *pcoords, Points *points,
            const double *fieldVals, int fieldDim, double *fieldDerivs)"""
        my_args = deref_array(args, [(('int', 'int', 'int'), ('float', Ellipsis), 'vtkPoints', ('float', Ellipsis), 'int', 'tuple')])
        ret = self._wrap_call(self._vtk_obj.WedgeEvaluateDerivative, *my_args)
        return ret

    _updateable_traits_ = \
    (('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('object_name', 'GetObjectName'),
    ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['debug', 'global_warning_display', 'object_name'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(HigherOrderInterpolation, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit HigherOrderInterpolation properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View(([], [], ['object_name']),
            title='Edit HigherOrderInterpolation properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit HigherOrderInterpolation properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

