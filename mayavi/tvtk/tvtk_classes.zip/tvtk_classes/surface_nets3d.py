# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.poly_data_algorithm import PolyDataAlgorithm


class SurfaceNets3D(PolyDataAlgorithm):
    r"""
    SurfaceNets3D - generate smoothed isocontours from segmented 3D
    image data (i.e., "label maps")
    
    Superclass: PolyDataAlgorithm
    
    SurfaceNets3D creates boundary/isocontour surfaces from a label
    map (e.g., a segmented image) using a threaded, 3D version of the
    multiple objects/labels Surface Nets algorithm. The input is a 3D
    image (i.e., volume) where each voxel is labeled (integer labels are
    preferred to real values), and the output data is a polygonal mesh
    separating labeled regions / objects.  (Note that on output each
    region [corresponding to a different segmented object] will share
    points/edges on a common boundary, i.e., two neighboring objects will
    share the boundary that separates them.) This threaded implementation
    uses concepts from Flying Edges to achieve high performance and
    scalability.
    
    The filter implements a contouring operation over a non-continuous
    scalar field. In comparison, classic contouring methods (like Flying
    Edges or Marching Cubes) presume a continuous scalar field. In
    comparision, this method processes non-continuous label maps, which
    corresponds to discrete regions in an input 3D image (i.e., volume).
    With a non-continuous scalar function, the usual data interpolation
    across a continuous function (e.g., interpolation along cell edges)
    is not possible. Instead, when the edge endpoint voxels are labeled
    in differing regions, the edge is split and transected by a quad
    polygon that connects the center points of the voxels on either side
    of the edge. Later, using a energy minimization smoothing process,
    the resulting polygonal mesh is adjusted to produce a smoother
    result. (Constraints on smoothing displacements may be specified to
    prevent excessive shrinkage and/or object distortion.)
    
    The smoothing process is controlled by setting a convergence measure,
    the number of smoothing iterations, the step size, and the allowed
    (constraint) distance that points may move.  These can be adjusted to
    provide the desired result. This class provides a method to access an
    internal instance of ConstrainedSmoothingFilter, through which
    these smoothing parameters may be specified, and which actually
    performs the smoothing operation. (Note: it is possible to skip the
    smoothing process altogether by disabling smoothing [e.g., invoking
    smoothing_off()] or setting the number of smoothing iterations to
    zero. This can be useful when using a different smoothing filter like
    WindowedSincPolyDataFilter; or if an unsmoothed, aliased output is
    desired. The reason the smoothing is built in to this filter is to
    remain faithful to the original published literature describing the
    Surface Nets algorithm, and for performance reasons since smoothing
    stencils can be generated on the fly.)
    
    The Surface Nets algorithm was first proposed by Sarah Frisken.  Two
    important papers include the description of surface nets for binary
    objects (i.e., extracting just one segmented object from a volume)
    and multi-label (multiple object extraction).
    
    S. Frisken (Gibson), “Constrained Elastic surface_nets: Generating
    Smooth Surfaces from Binary Segmented Data”, Proc. MICCAI, 1998,
    pp. 888-898.
    
    S. Frisken, “surface_nets for Multi-Label Segmentations with
    Preservation of Sharp Boundaries”, J. Computer Graphics Techniques,
    2022.
    
    Note that one nice feature of this filter is that algorithm execution
    occurs only once no matter the number of object labels / contour
    values. In many contouring-like algorithms, each separate contour
    value requires an additional algorithm execution with a new contour
    value. So in this filter large numbers of contour values do not
    significantly affect overall speed. The user can specify which
    objects (i.e., labels) are to be output to the filter. (Unspecified
    labels are treated as background and not output.)
    
    Besides output geometry defining the surface net, the filter outputs
    a two-component, cell data array indicating the labels/regions on
    either side of the polygons composing the output PolyData. (This
    can be used for advanced operations like extracting shared/contacting
    boundaries between two objects. The name of this cell data array is
    "boundary_labels".)
    
    Note also that the content of the filter's output can be controlled
    by specifying the output_style.  This produces different output which
    may better serve a particular workflow. For example, it is possible
    to produce just exterior boundary faces, or extract selected objects/
    labeled regions from the surface net.
    
    Implementation note: For performance reasons, this filter is
    internally implemented quite differently than described in the
    literature.  The main difference is that concepts from the Flying
    Edges parallel isocontouring algorithm are used. Namely, parallel,
    edge-by-edge processing is used to define cell cases, generate
    smoothing stencils, and produce points and output polygons. Plus the
    constrained smoothing process is also threaded using a
    double-buffering approach. For more information on Flying Edges see
    the paper:
    
    "Flying Edges: A High-Performance Scalable Isocontouring Algorithm"
    by Schroeder, Maynard, Geveci. Proc. of LDAV 2015. Chicago, IL.
    
    or visit VTK's FE implementation FlyingEdges3D.
    
    @warning
    This filter is specialized to 3D images.
    
    @warning
    The output of this filter is a polygonal mesh. By default when
    smoothing is disabled, the output is quad polygons. However, once
    smoothing is enabled, the quads are typically decomposed into
    triangles since the quads are typically no longer planar. A filter
    option is available to force the type of output polygonal mesh
    (quads, or triangles).
    
    @warning
    Subtle differences in the output may result when the number of
    objects / labels extracted changes. This is because the smoothing
    operation operates on all of the boundaries simultaneously. If the
    boundaries change due to a difference in the number of extracted
    regions / labels, then the smoothing operation can produce slightly
    different results.
    
    @warning
    The filters DiscreteMarchingCubes and DiscreteFlyingEdges3D
    also perform contouring of label maps. However these filters produce
    output that may not share coincident points and/or cells, or may
    produce "gaps" between segmented regions. For example,
    DiscreteMarchingCubes will share points between adjacent regions,
    but not triangle cells (which will be coincident). Also, no center
    point is inserted into voxels, meaning that intermittent gaps may
    form between regions. This Surface Nets implementation fully shares
    the boundary (points and cells) between adjacent objects; and no gaps
    between objects are formed (if the objects are neighbors to one
    another).
    
    @warning
    This class has been threaded with SMPTools. Using TBB or other
    non-sequential type (set in the CMake variable
    VTK_SMP_IMPLEMENTATION_TYPE) may improve performance significantly. 
    Note that for "small" volumes, serial execution may be faster due to
    the cost of managing threads. To force serial execution set
    VTK_IMPLEMENTATION_TYPE to "Sequential".
    
    @warning
    See also PackLabels which is a utility class for renumbering the
    labels found in the input segmentation mask to contiguous forms of
    smaller type.
    
    @sa
    SurfaceNets2D DiscreteMarchingCubes DiscreteFlyingEdges3D
    ConstrainedSmoothingFilter FlyingEdges3D
    WindowedSincPolyDataFilter PackLabels
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkSurfaceNets3D, obj, update, **traits)
    
    automatic_smoothing_constraints = tvtk_base.true_bool_trait(desc=\
        r"""
        Specify whether to set the smoothing constraints automatically.
        If automatic is on, the constraint distance and constraint box
        will calculated and set (based on the input size of the volume
        voxel). Note that the constraint_scale is used to adjust the size
        of the constraint distance or box when set automatically.
        (Typically the constraint distance defines a circumscribing
        sphere around a voxel, and the constraint box is a box with voxel
        spacing.)  If constraints are not set automatically, then the
        constraint distance and/or constraint box should be set
        manually.) By default, automatic smoothing constraints are
        enabled.
        """
    )

    def _automatic_smoothing_constraints_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetAutomaticSmoothingConstraints,
                        self.automatic_smoothing_constraints_)

    data_caching = tvtk_base.true_bool_trait(desc=\
        r"""
        Enable caching of intermediate data. A common workflow using this
        filter requires extracting object boundaries (i.e., the
        isocontour), and then repeatedly rerunning the smoothing process
        with different parameters. To improve performance by avoiding
        repeated extraction of the boundary, the filter can cache
        intermediate data prior to the smoothing process. In this way,
        the boundary is only extracted once, and as long as only the
        internal constrained smoothing filter is modified, then boundary
        extraction will not be reexecuted. By default this is enabled.
        """
    )

    def _data_caching_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetDataCaching,
                        self.data_caching_)

    optimized_smoothing_stencils = tvtk_base.true_bool_trait(desc=\
        r"""
        Indicate whether to use optimized smoothing stencils. Optimized
        stencils (which are on by default) are designed to better smooth
        sharp edges across the surface net. In some cases it may be
        desired to disable the use of optimized smoothing stencils.
        """
    )

    def _optimized_smoothing_stencils_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetOptimizedSmoothingStencils,
                        self.optimized_smoothing_stencils_)

    smoothing = tvtk_base.true_bool_trait(desc=\
        r"""
        Indicate whether smoothing should be enabled. By default, after
        the surface net is extracted, smoothing occurs using the built-in
        smoother. To disable smoothing, invoke smoothing_off().
        """
    )

    def _smoothing_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetSmoothing,
                        self.smoothing_)

    def get_constraint_strategy(self):
        """
        get_constraint_strategy(self) -> int
        C++: int get_constraint_strategy()"""
        ret = self._vtk_obj.GetConstraintStrategy()
        return ret
        

    def set_constraint_strategy_to_constraint_distance(self):
        """
        set_constraint_strategy_to_constraint_distance(self) -> None
        C++: void set_constraint_strategy_to_constraint_distance()"""
        self._vtk_obj.SetConstraintStrategyToConstraintDistance()

    output_mesh_type = tvtk_base.RevPrefixMap({'default': 0, 'quads': 2, 'triangles': 1}, default_value='default', desc=\
        r"""
        Control the type of output mesh. By default, if smoothing is off,
        the output mesh is a polygonal mesh consisting of quadrilaterals
        (quads). However, if smoothing is enabled, then the output mesh
        type is a polygonal mesh consisting of triangles. It is possible
        to force the output mesh type to be of a certain type (triangles,
        or quads) regardless whether smoothing is enabled or not. Note
        that if an output mesh is forced to be quads, and smoothing is
        enabled, the resulting quads may not be planar.
        """
    )

    def _output_mesh_type_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetOutputMeshType,
                        self.output_mesh_type_)

    output_style = tvtk_base.RevPrefixMap({'default': 0, 'boundary': 1, 'selected': 2}, default_value='default', desc=\
        r"""
        Specify the form (i.e., the style) of the output. Different
        styles are meant to support different workflows.
        OUTPUT_STYLE_DEFAULT provides the basic information defining the
        output surface net. OUTPUT_STYLE_BOUNDARY produces much smaller
        output since the interior polygon faces are not produced. 
        Finally, OUTPUT_STYLE_SELECTED enables the user to extract a
        subset of the labeled regions. This is useful because the
        smoothing operation will occur across all the specified input
        regions, meaning that the selected regions do not change shape
        due to changes in the specified input regions. You must specify
        the selected regions (i.e., labels) to output.
        """
    )

    def _output_style_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetOutputStyle,
                        self.output_style_)

    triangulation_strategy = tvtk_base.RevPrefixMap({'min_edge': 1, 'greedy': 0, 'min_area': 2}, default_value='min_edge', desc=\
        r"""
        Specify the strategy to triangulate the quads (not applicable if
        the output mesh type is set to MESH_TYPE_QUADS). If
        TRIANGULATE_GREEDY is specified, then quads are triangulated in
        no particular order. If TRIANGULATED_MIN_EDGE is specified, then
        trianglate the quad using a minimum-edge-length diagonal. If
        TRIANGULATED_MIN_AREA is specified, then trianglate the quad to
        produce a minimum surface area. By default, TRIANGULATE_MIN_EDGE
        is used. (Slight performance affects may occur, with
        TRIANGULATION_GREEDY generally the fastest.)
        """
    )

    def _triangulation_strategy_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetTriangulationStrategy,
                        self.triangulation_strategy_)

    array_component = traits.Int(0, enter_set=True, auto_set=False, desc=\
        r"""
        Set/get which component of a input multi-component scalar array
        to contour with; defaults to component 0.
        """
    )

    def _array_component_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetArrayComponent,
                        self.array_component)

    background_label = traits.Float(0.0, enter_set=True, auto_set=False, desc=\
        r"""
        This value specifies the label value to use when referencing the
        backround region outside of any of the specified regions. (This
        value is used when producing cell scalars.) By default this value
        is zero. Be very careful of the value being used here, it should
        not overlap an extracted label value, and because it is the same
        type as the input image scalars, make sure the value can be
        properly represented (e.g., if the input scalars are an unsigned
        type, then background_label should not be negative).
        """
    )

    def _background_label_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetBackgroundLabel,
                        self.background_label)

    constraint_box = traits.Array(enter_set=True, auto_set=False, shape=(3,), dtype="float", value=(1.0, 1.0, 1.0), cols=3, desc=\
        r"""
        
        """
    )

    def _constraint_box_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetConstraintBox,
                        self.constraint_box)

    constraint_distance = traits.Float(0.001, enter_set=True, auto_set=False, desc=\
        r"""
        
        """
    )

    def _constraint_distance_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetConstraintDistance,
                        self.constraint_distance)

    constraint_scale = traits.Trait(2.0, traits.Range(0.0, 100.0, enter_set=True, auto_set=False), desc=\
        r"""
        
        """
    )

    def _constraint_scale_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetConstraintScale,
                        self.constraint_scale)

    def get_label(self, *args):
        """
        get_label(self, i:int) -> float
        C++: double get_label(int i)"""
        ret = self._wrap_call(self._vtk_obj.GetLabel, *args)
        return ret

    def set_label(self, *args):
        """
        set_label(self, i:int, value:float) -> None
        C++: void set_label(int i, double value)"""
        ret = self._wrap_call(self._vtk_obj.SetLabel, *args)
        return ret

    number_of_contours = traits.Int(1, enter_set=True, auto_set=False, desc=\
        r"""
        
        """
    )

    def _number_of_contours_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetNumberOfContours,
                        self.number_of_contours)

    number_of_iterations = traits.Int(16, enter_set=True, auto_set=False, desc=\
        r"""
        Convenience methods that delegate to the internal smoothing
        filter follow below. See the documentation for
        ConstrainedSmoothingAlgorithm for more information.
        """
    )

    def _number_of_iterations_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetNumberOfIterations,
                        self.number_of_iterations)

    number_of_labels = traits.Int(1, enter_set=True, auto_set=False, desc=\
        r"""
        Set the number of labels to place into the list. You only really
        need to use this method to reduce list size. The method
        set_value() will automatically increase list size as needed. Note
        that for consistency with other isocountoring-related algorithms,
        some methods use "Labels" and "Contours" interchangeably.
        """
    )

    def _number_of_labels_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetNumberOfLabels,
                        self.number_of_labels)

    relaxation_factor = traits.Float(0.5, enter_set=True, auto_set=False, desc=\
        r"""
        
        """
    )

    def _relaxation_factor_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetRelaxationFactor,
                        self.relaxation_factor)

    def get_value(self, *args):
        """
        get_value(self, i:int) -> float
        C++: double get_value(int i)
        Get the ith label value.
        """
        ret = self._wrap_call(self._vtk_obj.GetValue, *args)
        return ret

    def set_value(self, *args):
        """
        set_value(self, i:int, value:float) -> None
        C++: void set_value(int i, double value)
        Set a particular label value at label number i. The index i
        ranges between (0 <= i < number_of_labels). (Note: while labels
        values are expressed as doubles, the underlying scalar data may
        be a different type. During execution the label values are cast
        to the type of the scalar data.)  Note the use of "Value" and
        "Label" when specifying regions to extract. The use of "Value" is
        consistent with other VTK continuous-scalar field isocontouring
        algorithms; however the term "Label" is more consistent with
        label maps.  Warning: make sure that the value of the background
        label (see definition below) is different than any of the
        specified labels, otherwise the generated cell scalars may be
        incorrect.
        """
        ret = self._wrap_call(self._vtk_obj.SetValue, *args)
        return ret

    def _get_input(self):
        try:
            return wrap_vtk(self._vtk_obj.GetInput(0))
        except TypeError:
            return wrap_vtk(self._vtk_obj.GetInput())
    input = traits.Property(_get_input,
                            desc="The first input of this object, i.e. the result of `get_input(0)`.")
    
    def get_input(self, *args):
        """
        get_input(self) -> DataObject
        C++: DataObject *get_input()
        get_input(self, port:int) -> DataObject
        C++: DataObject *get_input(int port)"""
        ret = self._wrap_call(self._vtk_obj.GetInput, *args)
        return wrap_vtk(ret)

    def _get_labels(self):
        return self._vtk_obj.GetLabels()
    labels = traits.Property(_get_labels, desc=\
        r"""
        
        """
    )

    def get_labels(self, *args):
        """
        get_labels(self) -> Pointer
        C++: double *get_labels()
        get_labels(self, contourValues:[float, ...]) -> None
        C++: void get_labels(double *contourValues)"""
        ret = self._wrap_call(self._vtk_obj.GetLabels, *args)
        return ret

    def _get_number_of_selected_labels(self):
        return self._vtk_obj.GetNumberOfSelectedLabels()
    number_of_selected_labels = traits.Property(_get_number_of_selected_labels, desc=\
        r"""
        
        """
    )

    def get_selected_label(self, *args):
        """
        get_selected_label(self, ithLabel:int) -> float
        C++: double get_selected_label(IdType ithLabel)"""
        ret = self._wrap_call(self._vtk_obj.GetSelectedLabel, *args)
        return ret

    def _get_smoother(self):
        return wrap_vtk(self._vtk_obj.GetSmoother())
    smoother = traits.Property(_get_smoother, desc=\
        r"""
        Get the instance of ConstrainedSmoothingFilter used to smooth
        the extracted surface net. To control smoothing, access this
        instance and specify its parameters such as number of smoothing
        iterations and constraint distance. If you wish to disable
        smoothing, set smoothing_off().
        """
    )

    def _get_values(self):
        return self._vtk_obj.GetValues()
    values = traits.Property(_get_values, desc=\
        r"""
        Get a pointer to an array of labels. There will be
        get_number_of_labels() values in the list.
        """
    )

    def get_values(self, *args):
        """
        get_values(self) -> Pointer
        C++: double *get_values()
        get_values(self, contourValues:[float, ...]) -> None
        C++: void get_values(double *contourValues)
        Get a pointer to an array of labels. There will be
        get_number_of_labels() values in the list.
        """
        ret = self._wrap_call(self._vtk_obj.GetValues, *args)
        return ret

    def add_selected_label(self, *args):
        """
        add_selected_label(self, label:float) -> None
        C++: void add_selected_label(double label)"""
        ret = self._wrap_call(self._vtk_obj.AddSelectedLabel, *args)
        return ret

    def delete_selected_label(self, *args):
        """
        delete_selected_label(self, label:float) -> None
        C++: void delete_selected_label(double label)"""
        ret = self._wrap_call(self._vtk_obj.DeleteSelectedLabel, *args)
        return ret

    def generate_labels(self, *args):
        """
        generate_labels(self, numLabels:int, range:[float, float]) -> None
        C++: void generate_labels(int numLabels, double range[2])
        generate_labels(self, numLabels:int, rangeStart:float,
            rangeEnd:float) -> None
        C++: void generate_labels(int numLabels, double rangeStart,
            double rangeEnd)
        Generate numLabels equally spaced labels between the specified
        range. The labels will include the min/max range values.
        """
        ret = self._wrap_call(self._vtk_obj.GenerateLabels, *args)
        return ret

    def generate_values(self, *args):
        """
        generate_values(self, numContours:int, range:[float, float])
            -> None
        C++: void generate_values(int numContours, double range[2])
        generate_values(self, numContours:int, rangeStart:float,
            rangeEnd:float) -> None
        C++: void generate_values(int numContours, double rangeStart,
            double rangeEnd)"""
        ret = self._wrap_call(self._vtk_obj.GenerateValues, *args)
        return ret

    def initialize_selected_labels_list(self):
        """
        initialize_selected_labels_list(self) -> None
        C++: void initialize_selected_labels_list()
        When the output_style is set to OUTPUT_STYLE_SELECTED, these
        methods are used to specify the labeled regions to output.
        """
        ret = self._vtk_obj.InitializeSelectedLabelsList()
        return ret
        

    _updateable_traits_ = \
    (('automatic_smoothing_constraints',
    'GetAutomaticSmoothingConstraints'), ('data_caching',
    'GetDataCaching'), ('optimized_smoothing_stencils',
    'GetOptimizedSmoothingStencils'), ('smoothing', 'GetSmoothing'),
    ('abort_execute', 'GetAbortExecute'), ('release_data_flag',
    'GetReleaseDataFlag'), ('debug', 'GetDebug'),
    ('global_warning_display', 'GetGlobalWarningDisplay'),
    ('output_mesh_type', 'GetOutputMeshType'), ('output_style',
    'GetOutputStyle'), ('triangulation_strategy',
    'GetTriangulationStrategy'), ('array_component', 'GetArrayComponent'),
    ('background_label', 'GetBackgroundLabel'), ('constraint_box',
    'GetConstraintBox'), ('constraint_distance', 'GetConstraintDistance'),
    ('constraint_scale', 'GetConstraintScale'), ('number_of_contours',
    'GetNumberOfContours'), ('number_of_iterations',
    'GetNumberOfIterations'), ('number_of_labels', 'GetNumberOfLabels'),
    ('relaxation_factor', 'GetRelaxationFactor'), ('abort_output',
    'GetAbortOutput'), ('progress_text', 'GetProgressText'),
    ('object_name', 'GetObjectName'), ('reference_count',
    'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['abort_execute', 'automatic_smoothing_constraints', 'data_caching',
    'debug', 'global_warning_display', 'optimized_smoothing_stencils',
    'release_data_flag', 'smoothing', 'output_mesh_type', 'output_style',
    'triangulation_strategy', 'abort_output', 'array_component',
    'background_label', 'constraint_box', 'constraint_distance',
    'constraint_scale', 'number_of_contours', 'number_of_iterations',
    'number_of_labels', 'object_name', 'progress_text',
    'relaxation_factor'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(SurfaceNets3D, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit SurfaceNets3D properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['automatic_smoothing_constraints', 'data_caching',
            'optimized_smoothing_stencils', 'smoothing'], ['output_mesh_type',
            'output_style', 'triangulation_strategy'], ['abort_output',
            'array_component', 'background_label', 'constraint_box',
            'constraint_distance', 'constraint_scale', 'number_of_contours',
            'number_of_iterations', 'number_of_labels', 'object_name',
            'relaxation_factor']),
            title='Edit SurfaceNets3D properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit SurfaceNets3D properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

