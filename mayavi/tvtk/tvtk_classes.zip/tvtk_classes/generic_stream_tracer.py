# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.poly_data_algorithm import PolyDataAlgorithm


class GenericStreamTracer(PolyDataAlgorithm):
    r"""
    GenericStreamTracer - Streamline generator
    
    Superclass: PolyDataAlgorithm
    
    GenericStreamTracer is a filter that integrates a vector field to
    generate streamlines. The integration is performed using the provided
    integrator. The default is second order Runge-Kutta.
    
    GenericStreamTracer generate polylines as output. Each cell
    (polyline) corresponds to one streamline. The values associated with
    each streamline are stored in the cell data whereas the values
    associated with points are stored in point data.
    
    Note that GenericStreamTracer can integrate both forward and
    backward. The length of the streamline is controlled by specifying
    either a maximum value in the units of length, cell length or elapsed
    time (the elapsed time is the time each particle would have traveled
    if flow were steady). Otherwise, the integration terminates after
    exiting the dataset or if the particle speed is reduced to a value
    less than the terminal speed or when a maximum number of steps is
    reached. The reason for the termination is stored in a cell array
    named reason_for_termination.
    
    The quality of integration can be controlled by setting integration
    step (initial_integration_step) and in the case of adaptive solvers the
    maximum error, the minimum integration step and the maximum
    integration step. All of these can have units of length, cell length
    or elapsed time.
    
    The integration time, vorticity, rotation and angular velocity are
    stored in point arrays named "integration_time", "Vorticity",
    "Rotation" and "angular_velocity" respectively (vorticity, rotation
    and angular velocity are computed only when compute_vorticity is on).
    All point attributes in the source data set are interpolated on the
    new streamline points.
    
    GenericStreamTracer integrates through any type of dataset. As a
    result, if the dataset contains 2D cells such as polygons or
    triangles, the integration is constrained to lie on the surface
    defined by the 2D cells.
    
    The starting point of traces may be defined in two different ways.
    Starting from global x-y-z "position" allows you to start a single
    trace at a specified x-y-z coordinate. If you specify a source
    object, a trace will be generated for each point in the source that
    is inside the dataset.
    
    @sa
    RibbonFilter RuledSurfaceFilter InitialValueProblemSolver
    RungeKutta2 RungeKutta4 RungeKutta45
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkGenericStreamTracer, obj, update, **traits)
    
    compute_vorticity = tvtk_base.true_bool_trait(desc=\
        r"""
        Turn on/off calculation of vorticity at streamline points
        (necessary for generating proper streamribbons using the
        RibbonFilter.
        """
    )

    def _compute_vorticity_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetComputeVorticity,
                        self.compute_vorticity_)

    initial_integration_step_unit = tvtk_base.RevPrefixMap({'cell_length_unit': 2, 'length_unit': 1, 'time_unit': 0}, default_value='cell_length_unit', desc=\
        r"""
        
        """
    )

    def _initial_integration_step_unit_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetInitialIntegrationStepUnit,
                        self.initial_integration_step_unit_)

    integration_direction = tvtk_base.RevPrefixMap({'forward': 0, 'backward': 1, 'both': 2}, default_value='forward', desc=\
        r"""
        Specify whether the streamtrace will be generated in the upstream
        or downstream direction.
        """
    )

    def _integration_direction_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetIntegrationDirection,
                        self.integration_direction_)

    integrator_type = tvtk_base.RevPrefixMap({'runge_kutta2': 0, 'runge_kutta4': 1, 'runge_kutta45': 2}, default_value='runge_kutta2', desc=\
        r"""
        
        """
    )

    def _integrator_type_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetIntegratorType,
                        self.integrator_type_)

    maximum_integration_step_unit = tvtk_base.RevPrefixMap({'cell_length_unit': 2, 'length_unit': 1, 'time_unit': 0}, default_value='cell_length_unit', desc=\
        r"""
        
        """
    )

    def _maximum_integration_step_unit_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetMaximumIntegrationStepUnit,
                        self.maximum_integration_step_unit_)

    maximum_propagation_unit = tvtk_base.RevPrefixMap({'length_unit': 1, 'cell_length_unit': 2, 'time_unit': 0}, default_value='length_unit', desc=\
        r"""
        
        """
    )

    def _maximum_propagation_unit_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetMaximumPropagationUnit,
                        self.maximum_propagation_unit_)

    minimum_integration_step_unit = tvtk_base.RevPrefixMap({'cell_length_unit': 2, 'length_unit': 1, 'time_unit': 0}, default_value='cell_length_unit', desc=\
        r"""
        
        """
    )

    def _minimum_integration_step_unit_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetMinimumIntegrationStepUnit,
                        self.minimum_integration_step_unit_)

    initial_integration_step = traits.Float(0.5, enter_set=True, auto_set=False, desc=\
        r"""
        Specify the initial step used in the integration expressed in one
        of the: TIME_UNIT        = 0 LENGTH_UNIT      = 1
        CELL_LENGTH_UNIT = 2 If the integrator is not adaptive, this is
        the actual step used.
        """
    )

    def _initial_integration_step_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetInitialIntegrationStep,
                        self.initial_integration_step)

    def _get_integrator(self):
        return wrap_vtk(self._vtk_obj.GetIntegrator())
    def _set_integrator(self, arg):
        old_val = self._get_integrator()
        self._wrap_call(self._vtk_obj.SetIntegrator,
                        deref_vtk(arg))
        self.trait_property_changed('integrator', old_val, arg)
    integrator = traits.Property(_get_integrator, _set_integrator, desc=\
        r"""
        
        """
    )

    maximum_error = traits.Float(1e-06, enter_set=True, auto_set=False, desc=\
        r"""
        Specify the maximum error in the integration. This value is
        passed to the integrator. Therefore, it's meaning depends on the
        integrator used.
        """
    )

    def _maximum_error_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetMaximumError,
                        self.maximum_error)

    maximum_integration_step = traits.Float(1.0, enter_set=True, auto_set=False, desc=\
        r"""
        Specify the maximum step used in the integration expressed in one
        of the: TIME_UNIT        = 0 LENGTH_UNIT      = 1
        CELL_LENGTH_UNIT = 2 Only valid when using adaptive integrators.
        """
    )

    def _maximum_integration_step_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetMaximumIntegrationStep,
                        self.maximum_integration_step)

    maximum_number_of_steps = traits.Int(2000, enter_set=True, auto_set=False, desc=\
        r"""
        Specify the maximum number of steps used in the integration.
        """
    )

    def _maximum_number_of_steps_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetMaximumNumberOfSteps,
                        self.maximum_number_of_steps)

    maximum_propagation = traits.Float(1.0, enter_set=True, auto_set=False, desc=\
        r"""
        Specify the maximum length of the streamlines expressed in one of
        the: TIME_UNIT        = 0 LENGTH_UNIT      = 1 CELL_LENGTH_UNIT =
        2
        """
    )

    def _maximum_propagation_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetMaximumPropagation,
                        self.maximum_propagation)

    minimum_integration_step = traits.Float(0.01, enter_set=True, auto_set=False, desc=\
        r"""
        Specify the minimum step used in the integration expressed in one
        of the: TIME_UNIT        = 0 LENGTH_UNIT      = 1
        CELL_LENGTH_UNIT = 2 Only valid when using adaptive integrators.
        """
    )

    def _minimum_integration_step_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetMinimumIntegrationStep,
                        self.minimum_integration_step)

    rotation_scale = traits.Float(1.0, enter_set=True, auto_set=False, desc=\
        r"""
        This can be used to scale the rate with which the streamribbons
        twist. The default is 1.
        """
    )

    def _rotation_scale_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetRotationScale,
                        self.rotation_scale)

    start_position = traits.Array(enter_set=True, auto_set=False, shape=(3,), dtype="float", value=(0.0, 0.0, 0.0), cols=3, desc=\
        r"""
        Specify the start of the streamline in the global coordinate
        system. Search must be performed to find initial cell to start
        integration from.
        """
    )

    def _start_position_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetStartPosition,
                        self.start_position)

    terminal_speed = traits.Float(1e-12, enter_set=True, auto_set=False, desc=\
        r"""
        If at any point, the speed is below this value, the integration
        is terminated.
        """
    )

    def _terminal_speed_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetTerminalSpeed,
                        self.terminal_speed)

    def _get_input(self):
        try:
            return wrap_vtk(self._vtk_obj.GetInput(0))
        except TypeError:
            return wrap_vtk(self._vtk_obj.GetInput())
    input = traits.Property(_get_input,
                            desc="The first input of this object, i.e. the result of `get_input(0)`.")
    
    def get_input(self, *args):
        """
        get_input(self) -> DataObject
        C++: DataObject *get_input()
        get_input(self, port:int) -> DataObject
        C++: DataObject *get_input(int port)"""
        ret = self._wrap_call(self._vtk_obj.GetInput, *args)
        return wrap_vtk(ret)

    def _get_input_vectors_selection(self):
        return self._vtk_obj.GetInputVectorsSelection()
    input_vectors_selection = traits.Property(_get_input_vectors_selection, desc=\
        r"""
        If you want to generate traces using an arbitrary vector array,
        then set its name here. By default this in nullptr and the filter
        will use the active vector array.
        """
    )

    def _get_source(self):
        return wrap_vtk(self._vtk_obj.GetSource())
    source = traits.Property(_get_source, desc=\
        r"""
        
        """
    )

    def fill_input_port_information(self, *args):
        """
        fill_input_port_information(self, port:int, info:Information)
            -> int
        C++: int fill_input_port_information(int port, Information *info)
            override;
        Fill the input port information objects for this algorithm.  This
        is invoked by the first call to get_input_port_information for each
        port so subclasses can specify what they can handle.
        """
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.FillInputPortInformation, *my_args)
        return ret

    def select_input_vectors(self, *args):
        """
        select_input_vectors(self, fieldName:str) -> None
        C++: void select_input_vectors(const char *fieldName)"""
        ret = self._wrap_call(self._vtk_obj.SelectInputVectors, *args)
        return ret

    def set_integration_step_unit(self, *args):
        """
        set_integration_step_unit(self, unit:int) -> None
        C++: void set_integration_step_unit(int unit)
        Simplified API to set an homogeneous unit across Min/Max/Init
        integration_step_unit
        """
        ret = self._wrap_call(self._vtk_obj.SetIntegrationStepUnit, *args)
        return ret

    def set_interpolator_prototype(self, *args):
        """
        set_interpolator_prototype(self,
            ivf:GenericInterpolatedVelocityField) -> None
        C++: void set_interpolator_prototype(
            GenericInterpolatedVelocityField *ivf)
        The object used to interpolate the velocity field during
        integration is of the same class as this prototype.
        """
        ret = self._wrap_call(self._vtk_obj.SetInterpolatorPrototype, *args)
        return ret

    def set_source_connection(self, *args):
        """
        set_source_connection(self, algOutput:AlgorithmOutput) -> None
        C++: void set_source_connection(AlgorithmOutput *algOutput)
        Specify the source object used to generate starting points
        (seeds). New style.
        """
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.SetSourceConnection, *my_args)
        return ret

    def set_source_data(self, *args):
        """
        set_source_data(self, source:DataSet) -> None
        C++: void set_source_data(DataSet *source)
        Specify the source object used to generate starting points.
        """
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.SetSourceData, *my_args)
        return ret

    _updateable_traits_ = \
    (('compute_vorticity', 'GetComputeVorticity'), ('abort_execute',
    'GetAbortExecute'), ('release_data_flag', 'GetReleaseDataFlag'),
    ('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('initial_integration_step_unit',
    'GetInitialIntegrationStepUnit'), ('integration_direction',
    'GetIntegrationDirection'), ('integrator_type', 'GetIntegratorType'),
    ('maximum_integration_step_unit', 'GetMaximumIntegrationStepUnit'),
    ('maximum_propagation_unit', 'GetMaximumPropagationUnit'),
    ('minimum_integration_step_unit', 'GetMinimumIntegrationStepUnit'),
    ('initial_integration_step', 'GetInitialIntegrationStep'),
    ('maximum_error', 'GetMaximumError'), ('maximum_integration_step',
    'GetMaximumIntegrationStep'), ('maximum_number_of_steps',
    'GetMaximumNumberOfSteps'), ('maximum_propagation',
    'GetMaximumPropagation'), ('minimum_integration_step',
    'GetMinimumIntegrationStep'), ('rotation_scale', 'GetRotationScale'),
    ('start_position', 'GetStartPosition'), ('terminal_speed',
    'GetTerminalSpeed'), ('abort_output', 'GetAbortOutput'),
    ('progress_text', 'GetProgressText'), ('object_name',
    'GetObjectName'), ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['abort_execute', 'compute_vorticity', 'debug',
    'global_warning_display', 'release_data_flag',
    'initial_integration_step_unit', 'integration_direction',
    'integrator_type', 'maximum_integration_step_unit',
    'maximum_propagation_unit', 'minimum_integration_step_unit',
    'abort_output', 'initial_integration_step', 'maximum_error',
    'maximum_integration_step', 'maximum_number_of_steps',
    'maximum_propagation', 'minimum_integration_step', 'object_name',
    'progress_text', 'rotation_scale', 'start_position',
    'terminal_speed'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(GenericStreamTracer, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit GenericStreamTracer properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['compute_vorticity'], ['initial_integration_step_unit',
            'integration_direction', 'integrator_type',
            'maximum_integration_step_unit', 'maximum_propagation_unit',
            'minimum_integration_step_unit'], ['abort_output',
            'initial_integration_step', 'maximum_error',
            'maximum_integration_step', 'maximum_number_of_steps',
            'maximum_propagation', 'minimum_integration_step', 'object_name',
            'rotation_scale', 'start_position', 'terminal_speed']),
            title='Edit GenericStreamTracer properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit GenericStreamTracer properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

