# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.object import Object


class ExecutableRunner(Object):
    r"""
    ExecutableRunner - Launch a process on the current machine and get
    its output
    
    Superclass: Object
    
    Launch a process on the current machine and get its standard output
    and standard error output. When `execute_in_system_shell` is false,
    arguments needs to be added separately using the `add_argument` /
    `clear_arguments` API, otherwise command may not work correctly. If
    one does not know how to parse the arguments of the command it want
    to execute then `execute_in_system_shell` should be set to true.
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkExecutableRunner, obj, update, **traits)
    
    execute_in_system_shell = tvtk_base.true_bool_trait(desc=\
        r"""
        Allows the command to be launched using the system shell (`sh` on
        unix systems, cmd.exe on windows). This is handy when the user
        doesn't know how to split arguments from a single string.
        
        Default to true.
        """
    )

    def _execute_in_system_shell_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetExecuteInSystemShell,
                        self.execute_in_system_shell_)

    right_trim_result = tvtk_base.true_bool_trait(desc=\
        r"""
        Set/Get if we trim the ending whitespaces of the output.
        
        Default is true.
        """
    )

    def _right_trim_result_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetRightTrimResult,
                        self.right_trim_result_)

    command = traits.String('', enter_set=True, auto_set=False, desc=\
        r"""
        
        """
    )

    def _command_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetCommand,
                        self.command)

    timeout = traits.Float(5.0, enter_set=True, auto_set=False, desc=\
        r"""
        Set/Get command timeout in seconds.  A non-positive (<= 0) value
        will disable the timeout.
        
        Default is 5
        """
    )

    def _timeout_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetTimeout,
                        self.timeout)

    def _get_number_of_arguments(self):
        return self._vtk_obj.GetNumberOfArguments()
    number_of_arguments = traits.Property(_get_number_of_arguments, desc=\
        r"""
        
        """
    )

    def _get_return_value(self):
        return self._vtk_obj.GetReturnValue()
    return_value = traits.Property(_get_return_value, desc=\
        r"""
        Get return value of last command. If no command has been executed
        or if the command has failed in some way value is != 0, else
        return 0.
        """
    )

    def _get_std_err(self):
        return self._vtk_obj.GetStdErr()
    std_err = traits.Property(_get_std_err, desc=\
        r"""
        
        """
    )

    def _get_std_out(self):
        return self._vtk_obj.GetStdOut()
    std_out = traits.Property(_get_std_out, desc=\
        r"""
        Get output of the previously run command.
        """
    )

    def add_argument(self, *args):
        """
        add_argument(self, arg:str) -> None
        C++: virtual void add_argument(const std::string &arg)
        API to control arguments passed to the command when
        `execute_in_system_shell` is false.
        
        Default is no argument.
        """
        ret = self._wrap_call(self._vtk_obj.AddArgument, *args)
        return ret

    def clear_arguments(self):
        """
        clear_arguments(self) -> None
        C++: virtual void clear_arguments()"""
        ret = self._vtk_obj.ClearArguments()
        return ret
        

    def execute(self):
        """
        execute(self) -> None
        C++: void execute()
        Execute the command currently set if any. This will update the
        std_out and std_err properties.
        """
        ret = self._vtk_obj.Execute()
        return ret
        

    _updateable_traits_ = \
    (('execute_in_system_shell', 'GetExecuteInSystemShell'),
    ('right_trim_result', 'GetRightTrimResult'), ('debug', 'GetDebug'),
    ('global_warning_display', 'GetGlobalWarningDisplay'), ('command',
    'GetCommand'), ('timeout', 'GetTimeout'), ('object_name',
    'GetObjectName'), ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['debug', 'execute_in_system_shell', 'global_warning_display',
    'right_trim_result', 'command', 'object_name', 'timeout'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(ExecutableRunner, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit ExecutableRunner properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['execute_in_system_shell', 'right_trim_result'], [],
            ['command', 'object_name', 'timeout']),
            title='Edit ExecutableRunner properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit ExecutableRunner properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

