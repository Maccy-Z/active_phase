# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.widget_representation import WidgetRepresentation


class Camera3DRepresentation(WidgetRepresentation):
    r"""
    Camera3DRepresentation - a class defining the representation for
    the Camera3DWidget
    
    Superclass: WidgetRepresentation
    
    This class is a concrete representation for the Camera3DWidget.
    The camera is represented by a box and a cone. The first one allows
    camera movement, the second allows view angle update. There are three
    more handles to rotate the view up, and move the target position. It
    also has a frustum representation.
    
    To use this representation, you can use the place_widget() method to
    position the widget looking at a specified region in space. This is
    optional as you may want to not move the camera at setup.
    
    @sa
    Camera3DWidget
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkCamera3DRepresentation, obj, update, **traits)
    
    frustum_visibility = tvtk_base.true_bool_trait(desc=\
        r"""
        Set/Get whether to show camera frustum. Default: true.
        """
    )

    def _frustum_visibility_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetFrustumVisibility,
                        self.frustum_visibility_)

    secondary_handles_visibility = tvtk_base.true_bool_trait(desc=\
        r"""
        Set/Get whether to show secondary handles (spheres and lines).
        Default: true.
        """
    )

    def _secondary_handles_visibility_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetSecondaryHandlesVisibility,
                        self.secondary_handles_visibility_)

    translating_all = tvtk_base.false_bool_trait(desc=\
        r"""
        Set/Get whether to translate both position and target or not.
        Default: false.
        """
    )

    def _translating_all_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetTranslatingAll,
                        self.translating_all_)

    translation_axis = tvtk_base.RevPrefixMap({'none': -1, 'x_axis': 0, 'y_axis': 1, 'z_axis': 2}, default_value='none', desc=\
        r"""
        
        """
    )

    def _translation_axis_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetTranslationAxis,
                        self.translation_axis_)

    def _get_camera(self):
        return wrap_vtk(self._vtk_obj.GetCamera())
    def _set_camera(self, arg):
        old_val = self._get_camera()
        self._wrap_call(self._vtk_obj.SetCamera,
                        deref_vtk(arg))
        self.trait_property_changed('camera', old_val, arg)
    camera = traits.Property(_get_camera, _set_camera, desc=\
        r"""
        
        """
    )

    front_handle_distance = traits.Trait(2.5, traits.Range(1.5, 1e+299, enter_set=True, auto_set=False), desc=\
        r"""
        Set/Get the distance betweem camera position and the front
        handle. Note that the distance is scaled with view to keep the
        widget the same size. Default: 2.5.
        """
    )

    def _front_handle_distance_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetFrontHandleDistance,
                        self.front_handle_distance)

    interaction_state = traits.Int(0, enter_set=True, auto_set=False, desc=\
        r"""
        The interaction state may be set from a widget (e.g.,
        Camera3DWidget) or other object. This controls how the
        interaction with the widget proceeds. Normally this method is
        used as part of a handshaking process with the widget: First
        compute_interaction_state() is invoked that returns a state based
        on geometric considerations (i.e., cursor near a widget feature),
        then based on events, the widget may modify this further.
        """
    )

    def _interaction_state_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetInteractionState,
                        self.interaction_state)

    up_handle_distance = traits.Trait(1.5, traits.Range(0.5, 1e+299, enter_set=True, auto_set=False), desc=\
        r"""
        Set/Get the distance betweem camera position and the up handle.
        Note that the distance is scaled with view to keep the widget the
        same size. Default: 1.5.
        """
    )

    def _up_handle_distance_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetUpHandleDistance,
                        self.up_handle_distance)

    _updateable_traits_ = \
    (('frustum_visibility', 'GetFrustumVisibility'),
    ('secondary_handles_visibility', 'GetSecondaryHandlesVisibility'),
    ('translating_all', 'GetTranslatingAll'), ('need_to_render',
    'GetNeedToRender'), ('picking_managed', 'GetPickingManaged'),
    ('dragable', 'GetDragable'), ('pickable', 'GetPickable'),
    ('use_bounds', 'GetUseBounds'), ('visibility', 'GetVisibility'),
    ('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('translation_axis',
    'GetTranslationAxis'), ('front_handle_distance',
    'GetFrontHandleDistance'), ('interaction_state',
    'GetInteractionState'), ('up_handle_distance', 'GetUpHandleDistance'),
    ('handle_size', 'GetHandleSize'), ('place_factor', 'GetPlaceFactor'),
    ('estimated_render_time', 'GetEstimatedRenderTime'),
    ('render_time_multiplier', 'GetRenderTimeMultiplier'), ('object_name',
    'GetObjectName'), ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['debug', 'dragable', 'frustum_visibility', 'global_warning_display',
    'need_to_render', 'pickable', 'picking_managed',
    'secondary_handles_visibility', 'translating_all', 'use_bounds',
    'visibility', 'translation_axis', 'estimated_render_time',
    'front_handle_distance', 'handle_size', 'interaction_state',
    'object_name', 'place_factor', 'render_time_multiplier',
    'up_handle_distance'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(Camera3DRepresentation, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit Camera3DRepresentation properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['frustum_visibility', 'need_to_render', 'picking_managed',
            'secondary_handles_visibility', 'translating_all', 'use_bounds',
            'visibility'], ['translation_axis'], ['estimated_render_time',
            'front_handle_distance', 'handle_size', 'interaction_state',
            'object_name', 'place_factor', 'render_time_multiplier',
            'up_handle_distance']),
            title='Edit Camera3DRepresentation properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit Camera3DRepresentation properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

