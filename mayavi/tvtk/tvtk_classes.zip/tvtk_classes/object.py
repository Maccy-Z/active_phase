# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.object_base import ObjectBase


class Object(ObjectBase):
    r"""
    Object - abstract base class for most VTK objects
    
    Superclass: ObjectBase
    
    Object is the base class for most objects in the visualization
    toolkit. Object provides methods for tracking modification time,
    debugging, printing, and event callbacks. Most objects created within
    the VTK framework should be a subclass of Object or one of its
    children.  The few exceptions tend to be very small helper classes
    that usually never get instantiated or situations where multiple
    inheritance gets in the way.  Object also performs reference
    counting: objects that are reference counted exist as long as another
    object uses them. Once the last reference to a reference counted
    object is removed, the object will spontaneously destruct.
    
    @warning
    Note: in VTK objects should always be created with the New() method
    and deleted with the Delete() method. VTK objects cannot be allocated
    off the stack (i.e., automatic objects) because the constructor is a
    protected method.
    
    @sa
    Command TimeStamp
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkObject, obj, update, **traits)
    
    debug = tvtk_base.false_bool_trait(desc=\
        r"""
        Set the value of the debug flag. A true value turns debugging on.
        """
    )

    def _debug_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetDebug,
                        self.debug_)

    global_warning_display = tvtk_base.true_bool_trait(desc=\
        r"""
        This is a global flag that controls whether any debug, warning or
        error messages are displayed.
        """
    )

    def _global_warning_display_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetGlobalWarningDisplay,
                        self.global_warning_display_)

    object_name = traits.String('', enter_set=True, auto_set=False, desc=\
        r"""
        Set/get the name of this object for reporting purposes. The name
        appears in warning and debug messages and in the Print output.
        Setting the object name does not change the MTime and does not
        invoke a modified_event. Derived classes implementing copying
        methods are expected not to copy the object_name.
        """
    )

    def _object_name_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetObjectName,
                        self.object_name)

    def get_command(self, *args):
        """
        get_command(self, tag:int) -> Command
        C++: Command *get_command(unsigned long tag)"""
        ret = self._wrap_call(self._vtk_obj.GetCommand, *args)
        return wrap_vtk(ret)

    def _get_m_time(self):
        return self._vtk_obj.GetMTime()
    m_time = traits.Property(_get_m_time, desc=\
        r"""
        Return this object's modified time.
        """
    )

    def add_observer(self, *args):
        """
        add_observer(self, event:int, command:Callback, priority:float=0.0) -> int
        C++: unsigned long add_observer(const char* event,
            Command* command, float priority=0.0f)
        Add an event callback command(o:Object, event:int) for an event type.
        Returns a handle that can be used with remove_event(event:int)."""
        ret = self._wrap_call(self._vtk_obj.AddObserver, *args)
        return ret

    def break_on_error(self):
        """
        break_on_error() -> None
        C++: static void break_on_error()
        This method is called when ErrorMacro executes. It allows the
        debugger to break on error.
        """
        ret = self._vtk_obj.BreakOnError()
        return ret
        

    def has_observer(self, *args):
        """
        has_observer(self, event:int, __b:Command) -> int
        C++: TypeBool has_observer(unsigned long event, Command *)
        has_observer(self, event:str, __b:Command) -> int
        C++: TypeBool has_observer(const char *event, Command *)
        has_observer(self, event:int) -> int
        C++: TypeBool has_observer(unsigned long event)
        has_observer(self, event:str) -> int
        C++: TypeBool has_observer(const char *event)"""
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.HasObserver, *my_args)
        return ret

    def invoke_event(self, *args):
        """
        invoke_event(self, event:int, callData:Any) -> int
        C++: int invoke_event(unsigned long event, void* callData)
        invoke_event(self, event:str, callData:Any) -> int
        C++: int invoke_event(const char* event, void* callData)
        invoke_event(self, event:int) -> int
        C++: int invoke_event(unsigned long event)
        invoke_event(self, event:str) -> int
        C++: int invoke_event(const char* event)
        This method invokes an event and returns whether the event was
        aborted or not. If the event was aborted, the return value is 1,
        otherwise it is 0."""
        ret = self._wrap_call(self._vtk_obj.InvokeEvent, *args)
        return ret

    def modified(self):
        """
        modified(self) -> None
        C++: virtual void modified()
        Update the modification time for this object. Many filters rely
        on the modification time to determine if they need to recompute
        their data. The modification time is a unique monotonically
        increasing unsigned long integer.
        """
        ret = self._vtk_obj.Modified()
        return ret
        

    def new_instance(self):
        """
        new_instance(self) -> Object
        C++: Object *new_instance()"""
        ret = wrap_vtk(self._vtk_obj.NewInstance())
        return ret
        

    def remove_all_observers(self):
        """
        remove_all_observers(self) -> None
        C++: void remove_all_observers()"""
        ret = self._vtk_obj.RemoveAllObservers()
        return ret
        

    def remove_observer(self, *args):
        """
        remove_observer(self, __a:Command) -> None
        C++: void remove_observer(Command *)
        remove_observer(self, tag:int) -> None
        C++: void remove_observer(unsigned long tag)"""
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.RemoveObserver, *my_args)
        return ret

    def remove_observers(self, *args):
        """
        remove_observers(self, event:int, __b:Command) -> None
        C++: void remove_observers(unsigned long event, Command *)
        remove_observers(self, event:str, __b:Command) -> None
        C++: void remove_observers(const char *event, Command *)
        remove_observers(self, event:int) -> None
        C++: void remove_observers(unsigned long event)
        remove_observers(self, event:str) -> None
        C++: void remove_observers(const char *event)"""
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.RemoveObservers, *my_args)
        return ret

    def safe_down_cast(self, *args):
        """
        safe_down_cast(o:ObjectBase) -> Object
        C++: static Object *safe_down_cast(ObjectBase *o)"""
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.SafeDownCast, *my_args)
        return wrap_vtk(ret)

    _updateable_traits_ = \
    (('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('object_name', 'GetObjectName'),
    ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['debug', 'global_warning_display', 'object_name'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(Object, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit Object properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View(([], [], ['object_name']),
            title='Edit Object properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit Object properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

