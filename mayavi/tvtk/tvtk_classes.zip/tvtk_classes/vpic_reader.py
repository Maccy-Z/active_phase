# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.image_algorithm import ImageAlgorithm


class VPICReader(ImageAlgorithm):
    r"""
    VPICReader - class for reading VPIC data files
    
    Superclass: ImageAlgorithm
    
    DataReader is a helper superclass that reads the vtk data file
    header, dataset type, and attribute data (point and cell attributes
    such as scalars, vectors, normals, etc.) from a vtk data file.  See
    text for the format of the various vtk file types.
    
    @sa
    PolyDataReader StructuredPointsReader StructuredGridReader
    UnstructuredGridReader RectilinearGridReader
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkVPICReader, obj, update, **traits)
    
    file_name = tvtk_base.vtk_file_name("", desc=\
        r"""
        Specify file name of VPIC data file to read.
        """
    )

    def _file_name_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetFileName,
                        self.file_name)

    def _get_output(self):
        return wrap_vtk(self._vtk_obj.GetOutput())
    
    def _set_output(self, obj):
        old_val = self._get_output()
        self._wrap_call(self._vtk_obj.SetOutput, deref_vtk(obj))
        self.trait_property_changed('output', old_val, obj)
    output = traits.Property(_get_output, _set_output,
                             desc="Output of this source, i.e. the result of `get_output()`.")
    
    def get_output(self, idx=None):
        """
        get_output(self) -> ImageData
        C++: ImageData *get_output()
        get_output(self, index:int) -> ImageData
        C++: ImageData *get_output(int index)
        Get the reader's output
        """
        if idx is None:
            return wrap_vtk(self._vtk_obj.GetOutput())
        else:
            return wrap_vtk(self._vtk_obj.GetOutput(idx))

    def set_output(self, obj):
        """
        set_output(self, d:DataObject) -> None
        C++: virtual void set_output(DataObject *d)"""
        old_val = self._get_output()
        self._wrap_call(self._vtk_obj.SetOutput, deref_vtk(obj))
        self.trait_property_changed('output', old_val, obj)

    def get_point_array_status(self, *args):
        """
        get_point_array_status(self, name:str) -> int
        C++: int get_point_array_status(const char *name)"""
        ret = self._wrap_call(self._vtk_obj.GetPointArrayStatus, *args)
        return ret

    def set_point_array_status(self, *args):
        """
        set_point_array_status(self, name:str, status:int) -> None
        C++: void set_point_array_status(const char *name, int status)"""
        ret = self._wrap_call(self._vtk_obj.SetPointArrayStatus, *args)
        return ret

    stride = traits.Array(enter_set=True, auto_set=False, shape=(3,), dtype="int", value=(1, 1, 1), cols=3, desc=\
        r"""
        Set the stride in each dimension
        """
    )

    def _stride_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetStride,
                        self.stride)

    def _get_input(self):
        try:
            return wrap_vtk(self._vtk_obj.GetInput(0))
        except TypeError:
            return wrap_vtk(self._vtk_obj.GetInput())
    input = traits.Property(_get_input,
                            desc="The first input of this object, i.e. the result of `get_input(0)`.")
    
    def get_input(self, *args):
        """
        get_input(self, port:int) -> DataObject
        C++: DataObject *get_input(int port)
        get_input(self) -> DataObject
        C++: DataObject *get_input()
        Get a data object for one of the input port connections.  The use
        of this method is strongly discouraged, but some filters that
        were written a long time ago still use this method.
        """
        ret = self._wrap_call(self._vtk_obj.GetInput, *args)
        return wrap_vtk(ret)

    def _get_number_of_point_arrays(self):
        return self._vtk_obj.GetNumberOfPointArrays()
    number_of_point_arrays = traits.Property(_get_number_of_point_arrays, desc=\
        r"""
        The following methods allow selective reading of solutions
        fields. By default, ALL data fields on the nodes are read, but
        this can be modified.
        """
    )

    def get_point_array_name(self, *args):
        """
        get_point_array_name(self, index:int) -> str
        C++: const char *get_point_array_name(int index)"""
        ret = self._wrap_call(self._vtk_obj.GetPointArrayName, *args)
        return ret

    def _get_x_layout(self):
        return self._vtk_obj.GetXLayout()
    x_layout = traits.Property(_get_x_layout, desc=\
        r"""
        
        """
    )

    def _get_y_layout(self):
        return self._vtk_obj.GetYLayout()
    y_layout = traits.Property(_get_y_layout, desc=\
        r"""
        
        """
    )

    def _get_z_layout(self):
        return self._vtk_obj.GetZLayout()
    z_layout = traits.Property(_get_z_layout, desc=\
        r"""
        
        """
    )

    def disable_all_point_arrays(self):
        """
        disable_all_point_arrays(self) -> None
        C++: void disable_all_point_arrays()"""
        ret = self._vtk_obj.DisableAllPointArrays()
        return ret
        

    def enable_all_point_arrays(self):
        """
        enable_all_point_arrays(self) -> None
        C++: void enable_all_point_arrays()"""
        ret = self._vtk_obj.EnableAllPointArrays()
        return ret
        

    def set_x_extent(self, *args):
        """
        set_x_extent(self, _arg1:int, _arg2:int) -> None
        C++: virtual void set_x_extent(int _arg1, int _arg2)
        set_x_extent(self, _arg:(int, int)) -> None
        C++: void set_x_extent(const int _arg[2])
        Set the simulation file decomposition in each dimension
        """
        ret = self._wrap_call(self._vtk_obj.SetXExtent, *args)
        return ret

    def set_y_extent(self, *args):
        """
        set_y_extent(self, _arg1:int, _arg2:int) -> None
        C++: virtual void set_y_extent(int _arg1, int _arg2)
        set_y_extent(self, _arg:(int, int)) -> None
        C++: void set_y_extent(const int _arg[2])"""
        ret = self._wrap_call(self._vtk_obj.SetYExtent, *args)
        return ret

    def set_z_extent(self, *args):
        """
        set_z_extent(self, _arg1:int, _arg2:int) -> None
        C++: virtual void set_z_extent(int _arg1, int _arg2)
        set_z_extent(self, _arg:(int, int)) -> None
        C++: void set_z_extent(const int _arg[2])"""
        ret = self._wrap_call(self._vtk_obj.SetZExtent, *args)
        return ret

    _updateable_traits_ = \
    (('abort_execute', 'GetAbortExecute'), ('release_data_flag',
    'GetReleaseDataFlag'), ('debug', 'GetDebug'),
    ('global_warning_display', 'GetGlobalWarningDisplay'), ('file_name',
    'GetFileName'), ('stride', 'GetStride'), ('progress_text',
    'GetProgressText'), ('object_name', 'GetObjectName'),
    ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['abort_execute', 'debug', 'global_warning_display',
    'release_data_flag', 'file_name', 'object_name', 'progress_text',
    'stride'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(VPICReader, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit VPICReader properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View(([], [], ['file_name', 'object_name', 'stride']),
            title='Edit VPICReader properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit VPICReader properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

